import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-iscr',
  templateUrl: './iscr.component.html',
  styleUrls: ['./iscr.component.css']
})
export class IscrComponent implements OnInit {

  constructor(private route:ActivatedRoute, private router: Router, private ds: DataService) { }
  id:any;
  c_id:any;
  data:any;
  result:any;
  a1: number = 0;  a2 : number = 0;  a3 : number = 0;  a4 : number = 0;   a5 : number = 0; a6 : number = 0; a7:number=0; a8:number=0;
  co1: number = 0;  co2 : number = 0;  co3 : number = 0;  co4 : number = 0;   co5 : number = 0; co6 : number = 0; co7:number=0; co8:number=0; co9:number=0;
  dp1: number = 0;  dp2 : number = 0;  dp3 : number = 0;  dp4 : number = 0;   dp5 : number = 0; dp6 : number = 0; dp7:number=0; dp8:number=0; dp9:number=0;
  in1: number = 0;  in2 : number = 0;  in3 : number = 0;  in4 : number = 0;   in5 : number = 0; in6 : number = 0; in7:number=0; in8:number=0; in9:number=0;
  ci1: number = 0;  ci2 : number = 0;  ci3 : number = 0;  ci4 : number = 0;   ci5 : number = 0; ci6 : number = 0; ci7:number=0; ci8:number=0; ci9:number=0;
  it1: number = 0;  it2 : number = 0;  it3 : number = 0;  it4 : number = 0;   it5 : number = 0; it6 : number = 0; it7:number=0; it8:number=0; it9:number=0;
  ds1: number = 0;  ds2 : number = 0;  ds3 : number = 0;  ds4 : number = 0;   ds5 : number = 0; ds6 : number = 0; ds7:number=0; ds8:number=0; ds9:number=0;
  ad1: number = 0;  ad2 : number = 0;  ad3 : number = 0;  ad4 : number = 0;   ad5 : number = 0; ad6 : number = 0; ad7:number=0; ad8:number=0; ad9:number=0;
ta1:number=0; ta2:number=0; ta3:number=0; ta4:number=0; t5:number=0;
tc1:number=0; tc2:number=0; tc3:number=0; tc4:number=0; tc5:number=0;
tt1:number=0; tt2:number=0; tt3:number=0; tt4:number=0; tt5:number=0;
ti1:number=0; ti2:number=0; ti3:number=0; ti4:number=0; ti5:number=0;
tn1:number=0; tn2:number=0; tn3:number=0; tn4:number=0; tn5:number=0;
tp1:number=0; tp2:number=0; tp3:number=0; tp4:number=0; tp5:number=0;


  ngOnInit(): void {
    this.update();
    this.getpfdata();
    this.getdata();

    this.id =this.route.snapshot.params['id'];
  }

  next(){

    this.router.navigateByUrl('/kfr/'+this.id);

  }

  getpfdata(){
    this.c_id =localStorage.getItem('c_id');
    this.ds.getpfdata(this.c_id).subscribe(res=>{
      this.data=res;
      console.log(res);
      // this.a1=this.data.np1;  this.a2=this.data.np2; this.a3=this.data.np3; 
       this.a4=this.data.np4; this.a5=this.data.np5;  this.a6=this.data.np6; this.a7=this.data.np7;  this.a8=this.data.np8; 
      // this.dp1=this.data.dp1;   this.dp2=this.data.dp2;   this.dp3=this.data.dp3;   
      this.dp4=this.data.dp4;   this.dp5=this.data.dp5;    this.dp6=this.data.dp6;   this.dp7=this.data.dp7;   this.dp8=this.data.dp8;
      this.in1=this.data.ti1;   this.in2=this.data.ti2;   this.in3=this.data.ti3;   this.in4=this.data.ti4;   this.in5=this.data.ti5;    this.in6=this.data.ti6;   this.in7=this.data.ti7;   this.in8=this.data.ti8;
      // this.ci1= this.a1 + this.dp1 + this.in1;
      // this.ci2= this.a2 + this.dp2 + this.in2;
      // this.ci3= this.a3 + this.dp3 + this.in3;
      this.ci4= this.a4 + this.dp4 + this.in4;
      this.ci5= this.a5 + this.dp5 + this.in5;
      this.ci6= this.a6 + this.dp6 + this.in6;
      this.ci7= this.a7 + this.dp7 + this.in7;
      this.ci8= this.a8 + this.dp8 + this.in8;
      this.t5=this.a1 + this.a2 + this.a3 + this.a4 + this.a5 + this.a6 + this.a7 + this.a8; 
      this.dp9=this.dp1 + this.dp2 + this.dp3 + this.dp4 + this.dp5 + this.dp6 + this.dp7 + this.dp8; 
      this.in9=this.in1 + this.in2 + this.in3 + this.in4 + this.in5 + this.in6 + this.in7 + this.in8; 
      this.ci9=this.ci1 + this.ci2 + this.ci3 + this.ci4 + this.ci5 + this.ci6 + this.ci7 + this.ci8; 

    });
  }
  getdata(){
    this.c_id =localStorage.getItem('c_id');
    this.ds.getdata(this.c_id).subscribe(response=>{
      this.result=response;
      // this.it1=this.in1;   this.it2=this.in2;   this.it3=this.in3;  
       this.it4=this.in5;   this.it5=this.in5;    this.it6=this.in6;   this.it7=this.in7;   this.it8=this.in8;

      // this.co1=  this.it1;
      // this.co2=  this.it2;
      // this.co3=  this.it3;
      this.co4=  this.it4;
      this.co5=  this.it5;
      this.co6=  this.it6;
      this.co7=  this.it7;
      this.co8=  this.it8;

      this.co9=this.co1 + this.co2 + this.co3 + this.co4 + this.co5 + this.co6 + this.co7 + this.co8; 
      this.it9=this.co1 + this.it2 + this.it3 + this.it4 + this.it5 + this.it6 + this.it7 + this.it8; 
this.ta1 = this.a1 + this.a2 + this.a3 + this.a4 ;
this.ta2 = this.a1 + this.a2 + this.a3 + this.a4 + this.a5;
this.ta3 = this.a1 + this.a2 + this.a3 + this.a4 + this.a5 + this.a6;
this.ta4 = this.a1 + this.a2 + this.a3 + this.a4 + this.a5 + this.a6 + this.a7;

this.tc1 = this.co1 + this.co2 + this.co3 + this.co4 ;
this.tc2 = this.co1 + this.co2 + this.co3 + this.co4 + this.co5;
this.tc3 = this.co1 + this.co2 + this.co3 + this.co4 + this.co5 + this.co6;
this.tc4 = this.co1 + this.co2 + this.co3 + this.co4 + this.co5 + this.co6 + this.co7;

this.tt1 = this.it1 + this.it2 + this.it3 + this.it4 ;
this.tt2 = this.it1 + this.it2 + this.it3 + this.it4 + this.it5;
this.tt3 = this.it1 + this.it2 + this.it3 + this.it4 + this.it5 + this.it6;
this.tt4 = this.it1 + this.it2 + this.it3 + this.it4 + this.it5 + this.it6 + this.it7;


this.ti1 = this.ci1 + this.ci2 + this.ci3 + this.ci4 ;
this.ti2 = this.ci1 + this.ci2 + this.ci3 + this.ci4 + this.ci5;
this.ti3 = this.ci1 + this.ci2 + this.ci3 + this.ci4 + this.ci5 + this.ci6;
this.ti4 = this.ci1 + this.ci2 + this.ci3 + this.ci4 + this.ci5 + this.ci6 + this.ci7;

this.tn1 = this.in1 + this.in2 + this.in3 + this.in4 ;
this.tn2 = this.in1 + this.in2 + this.in3 + this.in4 + this.in5;
this.tn3 = this.in1 + this.in2 + this.in3 + this.in4 + this.in5 + this.in6;
this.tn4 = this.in1 + this.in2 + this.in3 + this.in4 + this.in5 + this.in6 + this.in7;

this.tp1 = this.dp1 + this.dp2 + this.dp3 + this.dp4 ;
this.tp2 = this.dp1 + this.dp2 + this.dp3 + this.dp4 + this.dp5;
this.tp3 = this.dp1 + this.dp2 + this.dp3 + this.dp4 + this.dp5 + this.dp6;
this.tp4 = this.dp1 + this.dp2 + this.dp3 + this.dp4 + this.dp5 + this.dp6 + this.dp7;



      this.ds1= this.ci1 / this.co1;
      this.ds2= this.ci2 / this.co2;
      this.ds3= this.ci3 / this.co3;
      this.ds4= this.ci4 / this.co4;
      this.ds5= this.ci5 / this.co5;
      this.ds6= this.ci6 / this.co6;
      this.ds7= this.ci7 / this.co7;
      this.ds8= this.ci8 / this.co8;

      this.ad1 = this.ti1 / this.tc1;
      this.ad2 = this.ti2 / this.tc2; 
      this.ad3 = this.ti3 / this.tc3;
      this.ad4 = this.ti4 / this.tc4;
      this.ad5 = this.ci9 / this.co9;
     // console.log("co1 "+this.co1+"ci1 "+ this.ci1);

    });

  }

  update(){
   // this.t5=this.a1 + this.a2 + this.a3 + this.a4 + this.a5 + this.a6 + this.a7 + this.a8; 
// this.ci1= this.a1+this.dp1+this.it1;
// this.ci2= this.a2+this.dp2+this.it2;
// this.ci3= this.a3+this.dp3+this.it3;
// this.ci4= this.a4+this.dp4+this.it4;
// this.ci5= this.a5+this.dp5+this.it5;
// this.ci6= this.a6+this.dp6+this.it6;
// this.ci7= this.a7+this.dp7+this.it7;
// this.ci8= this.a8+this.dp8+this.it8;

// this.co1= this.il1 + this.it1;
// this.co2= this.il2 + this.it2;
// this.co3= this.il3 + this.it3;
// this.co4= this.il4 + this.it4;
// this.co5= this.il5 + this.it5;
// this.co6= this.il6 + this.it6;
// this.co7= this.il7 + this.it7;
// this.co8= this.il8 + this.it8;
  //  console.log("c1 : "+this.ci1);
  }

}
