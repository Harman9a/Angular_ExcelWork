export interface SheetData {
    name: string,
    cName: string,
    sheetType: string,
    year: number,
}