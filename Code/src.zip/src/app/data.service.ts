import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }

   demoapi(fdata){
  return this.http.post('http://localhost/EXCEL_WORK/Code/api.php',fdata);

   }

   addpf(pfdata){
    return this.http.post('http://localhost/EXCEL_WORK/Code/api.php',pfdata);
  
     }
   addcompany(cdata){
    return this.http.post('http://localhost/EXCEL_WORK/Code/api.php',cdata);

   }
   getclist(fd){
    return this.http.post('http://localhost/EXCEL_WORK/Code/api.php',fd);


   }
   getdata(id){
   

    return this.http.get('http://localhost/EXCEL_WORK/Code/getdata.php?id='+id);


   }

   getpfdata(pfid){
   

    return this.http.get<any>('http://localhost/EXCEL_WORK/Code/getdata.php?pfid='+pfid);


   }
   getcdata(cid){
   

    return this.http.get<any>('http://localhost/EXCEL_WORK/Code/getdata.php?cid='+cid);


   }

}
