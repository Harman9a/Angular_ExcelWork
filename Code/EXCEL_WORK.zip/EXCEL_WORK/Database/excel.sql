-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2021 at 11:33 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `excel_work`
--

-- --------------------------------------------------------

--
-- Table structure for table `balance_sheet`
--

CREATE TABLE `balance_sheet` (
  `id` int(255) NOT NULL,
  `ref_id` varchar(255) NOT NULL,
  `liabilities` longtext NOT NULL,
  `assets` longtext NOT NULL,
  `balancing` longtext NOT NULL,
  `TableHeader` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `balance_sheet`
--

INSERT INTO `balance_sheet` (`id`, `ref_id`, `liabilities`, `assets`, `balancing`, `TableHeader`) VALUES
(28, '1210035932', '{\"CURRENT_LIABILITIES\":{\"stbfb\":[{\"id\":1,\"value\":\"478.00\"},{\"id\":2,\"value\":\"490.00\"},{\"id\":3,\"value\":\"1000.00\"},{\"id\":4,\"value\":\"1000.00\"},{\"id\":5,\"value\":\"1000.00\"},{\"id\":6,\"value\":\"1000.00\"}],\"bs_bli\":[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"666.67\"},{\"id\":4,\"value\":\"666.67\"},{\"id\":5,\"value\":\"666.67\"},{\"id\":6,\"value\":\"0.00\"}],\"bs_stbfo\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_tc\":[{\"id\":1,\"value\":\"35.00\"},{\"id\":2,\"value\":\"39.45\"},{\"id\":3,\"value\":\"205.00\"},{\"id\":4,\"value\":\"257.67\"},{\"id\":5,\"value\":\"265.67\"},{\"id\":6,\"value\":\"230.00\"}],\"bs_apfc\":[{\"id\":1,\"value\":\"5.00\"},{\"id\":2,\"value\":\"5.05\"},{\"id\":3,\"value\":\"45.00\"},{\"id\":4,\"value\":\"100.00\"},{\"id\":5,\"value\":\"105.00\"},{\"id\":6,\"value\":\"80.00\"}],\"bs_tp\":[{\"id\":1,\"value\":\"10.00\"},{\"id\":2,\"value\":\"9.50\"},{\"id\":3,\"value\":\"16.00\"},{\"id\":4,\"value\":\"35.00\"},{\"id\":5,\"value\":\"35.00\"},{\"id\":6,\"value\":\"25.00\"}],\"bs_aetbp\":[{\"id\":1,\"value\":\"3.50\"},{\"id\":2,\"value\":\"3.45\"},{\"id\":3,\"value\":\"23.84\"},{\"id\":4,\"value\":\"35.00\"},{\"id\":5,\"value\":\"40.00\"},{\"id\":6,\"value\":\"25.00\"}],\"bs_ocl\":[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"0.00\"},{\"id\":4,\"value\":\"20.00\"},{\"id\":5,\"value\":\"20.00\"},{\"id\":6,\"value\":\"15.00\"}],\"bs_tcl\":[{\"id\":1,\"value\":\"531.50\"},{\"id\":2,\"value\":\"547.45\"},{\"id\":3,\"value\":\"1956.51\"},{\"id\":4,\"value\":\"2114.34\"},{\"id\":5,\"value\":\"2132.34\"},{\"id\":6,\"value\":\"1375.00\"}]},\"MEDIUM_AND_LONG_TERM_LIABILITIES\":{\"bs_btlo\":[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"1333.33\"},{\"id\":4,\"value\":\"666.66\"},{\"id\":5,\"value\":\"0.00\"},{\"id\":6,\"value\":\"0.00\"}],\"bs_lfd\":[{\"id\":1,\"value\":\"100.00\"},{\"id\":2,\"value\":\"100.00\"},{\"id\":3,\"value\":\"100.00\"},{\"id\":4,\"value\":\"100.00\"},{\"id\":5,\"value\":\"100.00\"},{\"id\":6,\"value\":\"100.00\"}],\"bs_lffar\":[{\"id\":1,\"value\":\"50.00\"},{\"id\":2,\"value\":\"50.00\"},{\"id\":3,\"value\":\"50.00\"},{\"id\":4,\"value\":\"50.00\"},{\"id\":5,\"value\":\"50.00\"},{\"id\":6,\"value\":\"50.00\"}],\"bs_ebaf\":[{\"id\":1,\"value\":\"15.50\"},{\"id\":2,\"value\":\"20.65\"},{\"id\":3,\"value\":\"25.00\"},{\"id\":4,\"value\":\"30.00\"},{\"id\":5,\"value\":\"35.00\"},{\"id\":6,\"value\":\"40.00\"}],\"bs_omltl\":[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"0.00\"},{\"id\":4,\"value\":\"0.00\"},{\"id\":5,\"value\":\"0.00\"},{\"id\":6,\"value\":\"0.00\"}],\"bs_tmltl\":[{\"id\":1,\"value\":\"165.50\"},{\"id\":2,\"value\":\"170.65\"},{\"id\":3,\"value\":\"1508.33\"},{\"id\":4,\"value\":\"846.66\"},{\"id\":5,\"value\":\"185.00\"},{\"id\":6,\"value\":\"190.00\"}]},\"CAPITAL_AND_RESERVE\":{\"bs_sc\":[{\"id\":1,\"value\":\"1000.00\"},{\"id\":2,\"value\":\"1000.00\"},{\"id\":3,\"value\":\"1500.00\"},{\"id\":4,\"value\":\"1500.00\"},{\"id\":5,\"value\":\"1500.00\"},{\"id\":6,\"value\":\"1500.00\"}],\"bs_gr\":[{\"id\":1,\"value\":\"25.00\"},{\"id\":2,\"value\":\"125.17\"},{\"id\":3,\"value\":\"236.90\"},{\"id\":4,\"value\":\"469.21\"},{\"id\":5,\"value\":\"773.00\"},{\"id\":6,\"value\":\"1185.67\"}],\"bs_resd\":[{\"id\":1,\"value\":\"100.17\"},{\"id\":2,\"value\":\"111.73\"},{\"id\":3,\"value\":\"232.31\"},{\"id\":4,\"value\":\"303.79\"},{\"id\":5,\"value\":\"412.67\"},{\"id\":6,\"value\":\"534.10\"}],\"bs_o\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_tcr\":[{\"id\":1,\"value\":\"1125.17\"},{\"id\":2,\"value\":\"1236.90\"},{\"id\":3,\"value\":\"1969.21\"},{\"id\":4,\"value\":\"2273.00\"},{\"id\":5,\"value\":\"2685.67\"},{\"id\":6,\"value\":\"3219.77\"}]},\"TOTAL_LIABILITIES\":[{\"id\":1,\"value\":\"1822.17\"},{\"id\":2,\"value\":\"1955.00\"},{\"id\":3,\"value\":\"5434.05\"},{\"id\":4,\"value\":\"5234.00\"},{\"id\":5,\"value\":\"5003.01\"},{\"id\":6,\"value\":\"4784.77\"}]}', '{\"CURRENT_ASSETS\":{\"bs_cih\":[{\"id\":1,\"value\":\"13.75\"},{\"id\":2,\"value\":\"14.35\"},{\"id\":3,\"value\":\"5.00\"},{\"id\":4,\"value\":\"5.00\"},{\"id\":5,\"value\":\"15.00\"},{\"id\":6,\"value\":\"40.23\"}],\"bs_bb\":[{\"id\":1,\"value\":\"59.04\"},{\"id\":2,\"value\":\"82.50\"},{\"id\":3,\"value\":\"35.00\"},{\"id\":4,\"value\":\"20\"},{\"id\":5,\"value\":\"56.67\"},{\"id\":6,\"value\":\"105\"}],\"bs_td\":[{\"id\":1,\"value\":\"650.79\"},{\"id\":2,\"value\":\"764.75\"},{\"id\":3,\"value\":\"845\"},{\"id\":4,\"value\":\"800\"},{\"id\":5,\"value\":\"955.88\"},{\"id\":6,\"value\":\"1030\"}],\"bs_sti\":[{\"id\":1,\"value\":\"10\"},{\"id\":2,\"value\":\"10\"},{\"id\":3,\"value\":\"10\"},{\"id\":4,\"value\":\"10\"},{\"id\":5,\"value\":\"10\"},{\"id\":6,\"value\":\"10\"}],\"bs_si\":[{\"id\":1,\"value\":\"700\"},{\"id\":2,\"value\":\"735\"},{\"id\":3,\"value\":\"1735\"},{\"id\":4,\"value\":\"2119\"},{\"id\":5,\"value\":\"2135\"},{\"id\":6,\"value\":\"2159\"}],\"bs_pe\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_ats\":[{\"id\":1,\"value\":\"28\"},{\"id\":2,\"value\":\"39\"},{\"id\":3,\"value\":\"40\"},{\"id\":4,\"value\":\"20\"},{\"id\":5,\"value\":\"25\"},{\"id\":6,\"value\":\"75\"}],\"bs_oca\":[{\"id\":1,\"value\":\"20.59\"},{\"id\":2,\"value\":\"29.40\"},{\"id\":3,\"value\":\"49.05\"},{\"id\":4,\"value\":\"10\"},{\"id\":5,\"value\":\"20.46\"},{\"id\":6,\"value\":\"45.54\"}],\"bs_tca\":[{\"id\":1,\"value\":\"1482.17\"},{\"id\":2,\"value\":\"1675.00\"},{\"id\":3,\"value\":\"2719.05\"},{\"id\":4,\"value\":\"2984.00\"},{\"id\":5,\"value\":\"3218.01\"},{\"id\":6,\"value\":\"3464.77\"}]},\"FIXED_ASSETS_AND_NON_CURRENT_ASSETS\":{\"bs_fanb\":[{\"id\":1,\"value\":\"340\"},{\"id\":2,\"value\":\"280\"},{\"id\":3,\"value\":\"2515\"},{\"id\":4,\"value\":\"2050\"},{\"id\":5,\"value\":\"1585\"},{\"id\":6,\"value\":\"1120\"}],\"bs_lti\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"200\"},{\"id\":4,\"value\":\"200\"},{\"id\":5,\"value\":\"200\"},{\"id\":6,\"value\":\"200\"}],\"bs_onca\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_tfa\":[{\"id\":1,\"value\":\"340.00\"},{\"id\":2,\"value\":\"280.00\"},{\"id\":3,\"value\":\"2715.00\"},{\"id\":4,\"value\":\"2250.00\"},{\"id\":5,\"value\":\"1785.00\"},{\"id\":6,\"value\":\"1320.00\"}]},\"INTANGIBLE_ASSETS\":{\"bs_gw\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_ple\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_oia\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"bs_tia\":[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"0.00\"},{\"id\":4,\"value\":\"0.00\"},{\"id\":5,\"value\":\"0.00\"},{\"id\":6,\"value\":\"0.00\"}]},\"TOTAL_ASSETS\":[{\"id\":1,\"value\":\"1822.17\"},{\"id\":2,\"value\":\"1955.00\"},{\"id\":3,\"value\":\"5434.05\"},{\"id\":4,\"value\":\"5234.00\"},{\"id\":5,\"value\":\"5003.01\"},{\"id\":6,\"value\":\"4784.77\"}]}', '[{\"id\":1,\"value\":\"0.00\"},{\"id\":2,\"value\":\"0.00\"},{\"id\":3,\"value\":\"0.00\"},{\"id\":4,\"value\":\"0.00\"},{\"id\":5,\"value\":\"0.00\"},{\"id\":6,\"value\":\"0.00\"}]', '{\"date\":[{\"id\":1,\"value\":\"30.09.20\"},{\"id\":2,\"value\":\"30.09.21\"},{\"id\":3,\"value\":\"30.09.22\"},{\"id\":4,\"value\":\"30.09.23\"},{\"id\":5,\"value\":\"30.09.24\"},{\"id\":6,\"value\":\"30.09.25\"}],\"heading\":[{\"id\":1,\"value\":\"Audited\"},{\"id\":2,\"value\":\"Unaudited \"},{\"id\":3,\"value\":\"Estimated\"},{\"id\":4,\"value\":\"Projected\"},{\"id\":5,\"value\":\"Projected\"},{\"id\":6,\"value\":\"Projected\"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `dscr_iscr`
--

CREATE TABLE `dscr_iscr` (
  `id` int(255) NOT NULL,
  `ref_id` varchar(255) NOT NULL,
  `dscr` longtext NOT NULL,
  `iscr` longtext NOT NULL,
  `TableHeader` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dscr_iscr`
--

INSERT INTO `dscr_iscr` (`id`, `ref_id`, `dscr`, `iscr`, `TableHeader`) VALUES
(21, '1210035932', '{\"Profit_After_Taxes\":{\"dscr_pat\":[{\"id\":1,\"value\":\"232.31\"},{\"id\":2,\"value\":\"303.80\"},{\"id\":3,\"value\":\"412.67\"},{\"id\":4,\"value\":\"534.19\"},{\"id\":5,\"value\":\"1482.97\"}]},\"Depreciation\":{\"dscr_d\":[{\"id\":1,\"value\":\"465\"},{\"id\":2,\"value\":\"465\"},{\"id\":3,\"value\":\"465\"},{\"id\":4,\"value\":\"465\"},{\"id\":5,\"value\":\"1860.00\"}]},\"Interest\":{\"dscr_i\":[{\"id\":1,\"value\":\"305.50\"},{\"id\":2,\"value\":\"301.19\"},{\"id\":3,\"value\":\"234.53\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"1009.97\"}]},\"Cash_Inflows\":{\"dscr_cif\":[{\"id\":1,\"value\":\"1002.81\"},{\"id\":2,\"value\":\"1069.99\"},{\"id\":3,\"value\":\"1112.20\"},{\"id\":4,\"value\":\"1167.94\"},{\"id\":5,\"value\":\"4352.94\"}]},\"Instalments_Payable\":{\"dscr_ip\":[{\"id\":1,\"value\":\"666.67\"},{\"id\":2,\"value\":\"666.67\"},{\"id\":3,\"value\":\"666.67\"},{\"id\":4,\"value\":\"0.00\"},{\"id\":5,\"value\":\"2000.01\"}]},\"Interest_Payable\":{\"dscr_intp\":[{\"id\":1,\"value\":\"305.50\"},{\"id\":2,\"value\":\"301.19\"},{\"id\":3,\"value\":\"234.53\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"1009.97\"}]},\"Cash_Outflows\":{\"dscr_cof\":[{\"id\":1,\"value\":\"972.17\"},{\"id\":2,\"value\":\"967.86\"},{\"id\":3,\"value\":\"901.20\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"3009.98\"}]},\"DSCR\":{\"dscr_dscr\":[{\"id\":1,\"value\":\"1.03\"},{\"id\":2,\"value\":\"1.11\"},{\"id\":3,\"value\":\"1.23\"},{\"id\":4,\"value\":\"6.92\"}]},\"Average_DSCR\":{\"dscr_avgdscr\":[{\"id\":\"x\",\"value\":\"1.45\"}]}}', '{\"Profit_After_Taxes\":{\"iscr_pat\":[{\"id\":1,\"value\":\"232.31\"},{\"id\":2,\"value\":\"303.80\"},{\"id\":3,\"value\":\"412.67\"},{\"id\":4,\"value\":\"534.19\"},{\"id\":5,\"value\":\"1482.97\"}]},\"Depreciation\":{\"iscr_d\":[{\"id\":1,\"value\":\"465\"},{\"id\":2,\"value\":\"465\"},{\"id\":3,\"value\":\"465\"},{\"id\":4,\"value\":\"465\"},{\"id\":5,\"value\":\"1860.00\"}]},\"Interest\":{\"iscr_i\":[{\"id\":1,\"value\":\"305.50\"},{\"id\":2,\"value\":\"301.19\"},{\"id\":3,\"value\":\"234.53\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"1009.97\"}]},\"Cash_Inflows\":{\"iscr_cif\":[{\"id\":1,\"value\":\"1002.81\"},{\"id\":2,\"value\":\"1069.99\"},{\"id\":3,\"value\":\"1112.20\"},{\"id\":4,\"value\":\"1167.94\"},{\"id\":5,\"value\":\"4352.94\"}]},\"Interest_Payable\":{\"iscr_intp\":[{\"id\":1,\"value\":\"305.50\"},{\"id\":2,\"value\":\"301.19\"},{\"id\":3,\"value\":\"234.53\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"1009.97\"}]},\"Cash_Outflows\":{\"iscr_cof\":[{\"id\":1,\"value\":\"305.50\"},{\"id\":2,\"value\":\"301.19\"},{\"id\":3,\"value\":\"234.53\"},{\"id\":4,\"value\":\"168.75\"},{\"id\":5,\"value\":\"1009.97\"}]},\"iscr\":{\"iscr_iscr\":[{\"id\":1,\"value\":\"3.28\"},{\"id\":2,\"value\":\"3.55\"},{\"id\":3,\"value\":\"4.74\"},{\"id\":4,\"value\":\"6.92\"}]},\"Average_ISCR\":{\"iscr_avgiscr\":[{\"id\":\"x\",\"value\":\"4.31\"}]}}', '{\"Ddate\":[{\"id\":1,\"value\":\"30.09.22\"},{\"id\":2,\"value\":\"30.09.23\"},{\"id\":3,\"value\":\"30.09.24\"},{\"id\":4,\"value\":\"30.09.25\"}],\"Idate\":[{\"id\":1,\"value\":\"30.09.22\"},{\"id\":2,\"value\":\"30.09.23\"},{\"id\":3,\"value\":\"30.09.24\"},{\"id\":4,\"value\":\"30.09.25\"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `key_financial_and_ratios`
--

CREATE TABLE `key_financial_and_ratios` (
  `id` int(250) NOT NULL,
  `ref_id` varchar(250) NOT NULL,
  `data` longtext NOT NULL,
  `TableHeader` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `key_financial_and_ratios`
--

INSERT INTO `key_financial_and_ratios` (`id`, `ref_id`, `data`, `TableHeader`) VALUES
(14, '1210035932', '{\"Share_Capital\":{\"kf_sc\":[{\"id\":1,\"value\":\"1000.00\"},{\"id\":2,\"value\":\"1000.00\"},{\"id\":3,\"value\":\"1500.00\"},{\"id\":4,\"value\":\"1500.00\"},{\"id\":5,\"value\":\"1500.00\"},{\"id\":6,\"value\":\"1500.00\"}]},\"Net_Worth\":{\"kf_nw\":[{\"id\":1,\"value\":\"1125.17\"},{\"id\":2,\"value\":\"1236.9\"},{\"id\":3,\"value\":\"1969.21\"},{\"id\":4,\"value\":\"2273\"},{\"id\":5,\"value\":\"2685.67\"},{\"id\":6,\"value\":\"3219.77\"}]},\"Net_Block\":{\"kf_nb\":[{\"id\":1,\"value\":\"340\"},{\"id\":2,\"value\":\"280\"},{\"id\":3,\"value\":\"2515\"},{\"id\":4,\"value\":\"2050\"},{\"id\":5,\"value\":\"1585\"},{\"id\":6,\"value\":\"1120\"}]},\"Net_Sales\":{\"kf_ns\":[{\"id\":1,\"value\":\"2878.50\"},{\"id\":2,\"value\":\"3038.10\"},{\"id\":3,\"value\":\"3605.25\"},{\"id\":4,\"value\":\"4536.25\"},{\"id\":5,\"value\":\"5381.75\"},{\"id\":6,\"value\":\"6175.00\"}]},\"Increase_in_Sales\":{\"kf_iis\":[{\"id\":1,\"value\":\"6%\"},{\"id\":2,\"value\":\"19%\"},{\"id\":3,\"value\":\"26%\"},{\"id\":4,\"value\":\"19%\"},{\"id\":5,\"value\":\"15%\"}]},\"Net_Profit\":{\"kf_np\":[{\"id\":1,\"value\":\"100.17\"},{\"id\":2,\"value\":\"111.73\"},{\"id\":3,\"value\":\"232.31\"},{\"id\":4,\"value\":\"303.80\"},{\"id\":5,\"value\":\"412.67\"},{\"id\":6,\"value\":\"534.19\"}]},\"Depreciation\":{\"kf_dp\":[{\"id\":1,\"value\":\"60\"},{\"id\":2,\"value\":\"60\"},{\"id\":3,\"value\":\"465\"},{\"id\":4,\"value\":\"465\"},{\"id\":5,\"value\":\"465\"},{\"id\":6,\"value\":\"465\"}]},\"Cash_Accruals\":{\"kf_ca\":[{\"id\":1,\"value\":\"160.17\"},{\"id\":2,\"value\":\"171.73\"},{\"id\":3,\"value\":\"697.31\"},{\"id\":4,\"value\":\"768.80\"},{\"id\":5,\"value\":\"877.67\"},{\"id\":6,\"value\":\"999.19\"}]},\"Profitability_Ratio\":{\"kf_pr\":[{\"id\":1,\"value\":\"3.48%\"},{\"id\":2,\"value\":\"3.68%\"},{\"id\":3,\"value\":\"6.44%\"},{\"id\":4,\"value\":\"6.70%\"},{\"id\":5,\"value\":\"7.67%\"},{\"id\":6,\"value\":\"8.65%\"}]},\"Current_Assets\":{\"kf_cas\":[{\"id\":1,\"value\":\"1482.17\"},{\"id\":2,\"value\":\"1675.00\"},{\"id\":3,\"value\":\"2719.05\"},{\"id\":4,\"value\":\"2984.00\"},{\"id\":5,\"value\":\"3218.01\"},{\"id\":6,\"value\":\"3464.77\"}]},\"Return_On_Capital_Employed\":{\"kf_roc\":[{\"id\":1,\"value\":\"8.90%\"},{\"id\":2,\"value\":\"9.03%\"},{\"id\":3,\"value\":\"11.80%\"},{\"id\":4,\"value\":\"13.37%\"},{\"id\":5,\"value\":\"15.37%\"},{\"id\":6,\"value\":\"16.59%\"}]},\"Current_Liabilities\":{\"kf_cl\":[{\"id\":1,\"value\":\"531.50\"},{\"id\":2,\"value\":\"547.45\"},{\"id\":3,\"value\":\"1956.51\"},{\"id\":4,\"value\":\"2114.34\"},{\"id\":5,\"value\":\"2132.34\"},{\"id\":6,\"value\":\"1375.00\"}]},\"Current_Ratio\":{\"kf_cr\":[{\"id\":1,\"value\":\"2.79\"},{\"id\":2,\"value\":\"3.06\"},{\"id\":3,\"value\":\"1.39\"},{\"id\":4,\"value\":\"1.41\"},{\"id\":5,\"value\":\"1.51\"},{\"id\":6,\"value\":\"2.52\"}]},\"Debt_Equity_Ratio\":{\"kf_nwDR\":[{\"id\":1,\"value\":\"0.62\"},{\"id\":2,\"value\":\"0.58\"},{\"id\":3,\"value\":\"1.76\"},{\"id\":4,\"value\":\"1.30\"},{\"id\":5,\"value\":\"0.86\"},{\"id\":6,\"value\":\"0.49\"}]},\"Debt_Service_Coverage_Ratio\":{\"dfs_cr\":[{\"id\":1,\"value\":\"1.03\"},{\"id\":2,\"value\":\"1.11\"},{\"id\":3,\"value\":\"1.23\"},{\"id\":4,\"value\":\"6.92\"}]},\"DSCR\":{\"kf_da\":[{\"id\":1,\"value\":\"1.45\"}]},\"Interest_Service_Coverage_Ratio\":{\"kf_iscr\":[{\"id\":1,\"value\":\"3.28\"},{\"id\":2,\"value\":\"3.55\"},{\"id\":3,\"value\":\"4.74\"},{\"id\":4,\"value\":\"6.92\"}]},\"ISCR\":{\"kf_ia\":[{\"id\":1,\"value\":\"4.31\"}]},\"Debt_Collection_Period\":{\"kf_nwDC\":[{\"id\":1,\"value\":\"83\"},{\"id\":2,\"value\":\"92\"},{\"id\":3,\"value\":\"86\"},{\"id\":4,\"value\":\"64\"},{\"id\":5,\"value\":\"65\"},{\"id\":6,\"value\":\"61\"}]}}', '');

-- --------------------------------------------------------

--
-- Table structure for table `profit_loss`
--

CREATE TABLE `profit_loss` (
  `id` int(255) NOT NULL,
  `ref_id` int(255) NOT NULL,
  `data` longtext NOT NULL,
  `TableHeader` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profit_loss`
--

INSERT INTO `profit_loss` (`id`, `ref_id`, `data`, `TableHeader`) VALUES
(21, 1210035932, '{\"Sales_Revenue\":{\"pal_d\":[{\"id\":1,\"value\":\"2878.50\"},{\"id\":2,\"value\":\"3038.10\"},{\"id\":3,\"value\":\"3605.25\"},{\"id\":4,\"value\":\"4536.25\"},{\"id\":5,\"value\":\"5381.75\"},{\"id\":6,\"value\":\"6175\"}],\"pal_e\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"pal_tns\":[{\"id\":1,\"value\":\"2878.50\"},{\"id\":2,\"value\":\"3038.10\"},{\"id\":3,\"value\":\"3605.25\"},{\"id\":4,\"value\":\"4536.25\"},{\"id\":5,\"value\":\"5381.75\"},{\"id\":6,\"value\":\"6175.00\"}]},\"Cost_of_Sales\":{\"pal_rmsp\":[{\"id\":1,\"value\":\"1745\"},{\"id\":2,\"value\":\"1762\"},{\"id\":3,\"value\":\"2195\"},{\"id\":4,\"value\":\"2345\"},{\"id\":5,\"value\":\"2635\"},{\"id\":6,\"value\":\"3175\"}],\"pal_os\":[{\"id\":1,\"value\":\"285\"},{\"id\":2,\"value\":\"295\"},{\"id\":3,\"value\":\"355\"},{\"id\":4,\"value\":\"415\"},{\"id\":5,\"value\":\"465\"},{\"id\":6,\"value\":\"540\"}],\"pal_pf\":[{\"id\":1,\"value\":\"95\"},{\"id\":2,\"value\":\"102\"},{\"id\":3,\"value\":\"120\"},{\"id\":4,\"value\":\"132\"},{\"id\":5,\"value\":\"145\"},{\"id\":6,\"value\":\"165\"}],\"pal_dlc\":[{\"id\":1,\"value\":\"510\"},{\"id\":2,\"value\":\"519\"},{\"id\":3,\"value\":\"575\"},{\"id\":4,\"value\":\"600\"},{\"id\":5,\"value\":\"625\"},{\"id\":6,\"value\":\"670\"}],\"pal_rfag\":[{\"id\":1,\"value\":\"18\"},{\"id\":2,\"value\":\"18\"},{\"id\":3,\"value\":\"54\"},{\"id\":4,\"value\":\"54\"},{\"id\":5,\"value\":\"60\"},{\"id\":6,\"value\":\"60\"}],\"pal_cosd\":[{\"id\":1,\"value\":\"60\"},{\"id\":2,\"value\":\"60\"},{\"id\":3,\"value\":\"465\"},{\"id\":4,\"value\":\"465\"},{\"id\":5,\"value\":\"465\"},{\"id\":6,\"value\":\"465\"}],\"pal_ode\":[{\"id\":1,\"value\":\"15.25\"},{\"id\":2,\"value\":\"16.25\"},{\"id\":3,\"value\":\"25\"},{\"id\":4,\"value\":\"30\"},{\"id\":5,\"value\":\"35\"},{\"id\":6,\"value\":\"45\"}],\"pal_stcos\":[{\"id\":1,\"value\":\"2728.25\"},{\"id\":2,\"value\":\"2772.25\"},{\"id\":3,\"value\":\"3789.00\"},{\"id\":4,\"value\":\"4041.00\"},{\"id\":5,\"value\":\"4430.00\"},{\"id\":6,\"value\":\"5120.00\"}],\"pal_aos\":[{\"id\":1,\"value\":\"549\"},{\"id\":2,\"value\":\"700\"},{\"id\":3,\"value\":\"765\"},{\"id\":4,\"value\":\"1735\"},{\"id\":5,\"value\":\"2119\"},{\"id\":6,\"value\":\"2135\"}],\"pal_dcs\":[{\"id\":1,\"value\":\"700\"},{\"id\":2,\"value\":\"765\"},{\"id\":3,\"value\":\"1735\"},{\"id\":4,\"value\":\"2119\"},{\"id\":5,\"value\":\"2135\"},{\"id\":6,\"value\":\"2159\"}]},\"Cost_of_Production\":{\"pal_stcop\":[{\"id\":1,\"value\":\"2577.25\"},{\"id\":2,\"value\":\"2707.25\"},{\"id\":3,\"value\":\"2819.00\"},{\"id\":4,\"value\":\"3657.00\"},{\"id\":5,\"value\":\"4414.00\"},{\"id\":6,\"value\":\"5096.00\"}]},\"General_and_Admin_Expneses\":{\"pal_gaae\":[{\"id\":1,\"value\":\"95\"},{\"id\":2,\"value\":\"102\"},{\"id\":3,\"value\":\"178\"},{\"id\":4,\"value\":\"185\"},{\"id\":5,\"value\":\"195\"},{\"id\":6,\"value\":\"210\"}]},\"Cost_of_SalesT\":{\"pal_cosT\":[{\"id\":1,\"value\":\"2672.25\"},{\"id\":2,\"value\":\"2809.25\"},{\"id\":3,\"value\":\"2997.00\"},{\"id\":4,\"value\":\"3842.00\"},{\"id\":5,\"value\":\"4609.00\"},{\"id\":6,\"value\":\"5306.00\"}]},\"Operating_Profit\":{\"pal_op\":[{\"id\":1,\"value\":\"206.25\"},{\"id\":2,\"value\":\"228.85\"},{\"id\":3,\"value\":\"608.25\"},{\"id\":4,\"value\":\"694.25\"},{\"id\":5,\"value\":\"772.75\"},{\"id\":6,\"value\":\"869.00\"}]},\"Non_Operating_Expenses\":{\"pal_inbb\":[{\"id\":1,\"value\":\"50\"},{\"id\":2,\"value\":\"50\"},{\"id\":3,\"value\":\"275\"},{\"id\":4,\"value\":\"269.44\"},{\"id\":5,\"value\":\"202.78\"},{\"id\":6,\"value\":\"136\"}],\"pal_iolfo\":[{\"id\":1,\"value\":\"18\"},{\"id\":2,\"value\":\"18\"},{\"id\":3,\"value\":\"18\"},{\"id\":4,\"value\":\"18\"},{\"id\":5,\"value\":\"18\"},{\"id\":6,\"value\":\"18\"}],\"pal_onoe\":[{\"id\":1,\"value\":\"4.75\"},{\"id\":2,\"value\":\"11.98\"},{\"id\":3,\"value\":\"12.50\"},{\"id\":4,\"value\":\"13.75\"},{\"id\":5,\"value\":\"13.75\"},{\"id\":6,\"value\":\"14.75\"}],\"pal_stnoe\":[{\"id\":1,\"value\":\"72.75\"},{\"id\":2,\"value\":\"79.98\"},{\"id\":3,\"value\":\"305.50\"},{\"id\":4,\"value\":\"301.19\"},{\"id\":5,\"value\":\"234.53\"},{\"id\":6,\"value\":\"168.75\"}]},\"Non_Operating_Income\":{\"pal_ii\":[{\"id\":1,\"value\":\"0.06\"},{\"id\":2,\"value\":\"0.60\"},{\"id\":3,\"value\":\"7\"},{\"id\":4,\"value\":\"12\"},{\"id\":5,\"value\":\"12\"},{\"id\":6,\"value\":\"12\"}],\"pal_onoi\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}],\"pal_stnoi\":[{\"id\":1,\"value\":\"0.06\"},{\"id\":2,\"value\":\"0.60\"},{\"id\":3,\"value\":\"7.00\"},{\"id\":4,\"value\":\"12.00\"},{\"id\":5,\"value\":\"12.00\"},{\"id\":6,\"value\":\"12.00\"}]},\"Profit_before_Taxes\":{\"pal_pbt\":[{\"id\":1,\"value\":\"133.56\"},{\"id\":2,\"value\":\"148.97\"},{\"id\":3,\"value\":\"309.75\"},{\"id\":4,\"value\":\"405.06\"},{\"id\":5,\"value\":\"550.22\"},{\"id\":6,\"value\":\"712.25\"}]},\"Provision_for_taxation\":{\"pal_pft\":[{\"id\":1,\"value\":\"33.39\"},{\"id\":2,\"value\":\"37.24\"},{\"id\":3,\"value\":\"77.44\"},{\"id\":4,\"value\":\"101.260\"},{\"id\":5,\"value\":\"137.55\"},{\"id\":6,\"value\":\"178.06\"}]},\"Net_Profit\":{\"pal_np\":[{\"id\":1,\"value\":\"100.17\"},{\"id\":2,\"value\":\"111.73\"},{\"id\":3,\"value\":\"232.31\"},{\"id\":4,\"value\":\"303.80\"},{\"id\":5,\"value\":\"412.67\"},{\"id\":6,\"value\":\"534.19\"}]},\"Dividend_Withdrawals\":{\"pal_dw\":[{\"id\":1,\"value\":\"0\"},{\"id\":2,\"value\":\"0\"},{\"id\":3,\"value\":\"0\"},{\"id\":4,\"value\":\"0\"},{\"id\":5,\"value\":\"0\"},{\"id\":6,\"value\":\"0\"}]},\"Retained_profit\":{\"pal_rp\":[{\"id\":1,\"value\":\"100.17\"},{\"id\":2,\"value\":\"111.73\"},{\"id\":3,\"value\":\"232.31\"},{\"id\":4,\"value\":\"303.80\"},{\"id\":5,\"value\":\"412.67\"},{\"id\":6,\"value\":\"534.19\"}]}}', '{\"date\":[{\"id\":1,\"value\":\"30.09.20\"},{\"id\":2,\"value\":\"30.09.21\"},{\"id\":3,\"value\":\"30.09.22\"},{\"id\":4,\"value\":\"30.09.23\"},{\"id\":5,\"value\":\"30.09.24\"},{\"id\":6,\"value\":\"30.09.25\"}],\"heading\":[{\"id\":1,\"value\":\"Audited\"},{\"id\":2,\"value\":\"Unaudited\"},{\"id\":3,\"value\":\"Estimated\"},{\"id\":4,\"value\":\"Projected\"},{\"id\":5,\"value\":\"Projected\"},{\"id\":6,\"value\":\"Projected\"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `sheets`
--

CREATE TABLE `sheets` (
  `id` int(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `ref_id` int(250) NOT NULL,
  `user_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sheets`
--

INSERT INTO `sheets` (`id`, `company_name`, `description`, `ref_id`, `user_id`) VALUES
(26, 'demo', '121212', 1210035932, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`) VALUES
(1, 'Harman', 'Harman@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(2, 'test', 'test@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(3, 'test2', 'test2@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `balance_sheet`
--
ALTER TABLE `balance_sheet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dscr_iscr`
--
ALTER TABLE `dscr_iscr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `key_financial_and_ratios`
--
ALTER TABLE `key_financial_and_ratios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profit_loss`
--
ALTER TABLE `profit_loss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sheets`
--
ALTER TABLE `sheets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `balance_sheet`
--
ALTER TABLE `balance_sheet`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `dscr_iscr`
--
ALTER TABLE `dscr_iscr`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `key_financial_and_ratios`
--
ALTER TABLE `key_financial_and_ratios`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `profit_loss`
--
ALTER TABLE `profit_loss`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `sheets`
--
ALTER TABLE `sheets`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
