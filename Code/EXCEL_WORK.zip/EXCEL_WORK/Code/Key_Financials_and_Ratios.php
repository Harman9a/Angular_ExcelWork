<?php include('config.php'); 

session_start();

if(!isset($_SESSION['id'])){
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <style>
    @page { margin: 0; }
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 5px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }

    .styled-table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }

    .heading {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-size: 0.9em;
        font-family: sans-serif;
        padding: 12px 15px;
    }
    </style>
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
</head>
<body>
    <div class="row">
        <div class="col-sm-4">
                <h2>Key Financials and Ratios</h2>
            </div>
            <div class="col-sm-7">
                <h2>Company Name: <?php echo $_SESSION['company_name']; ?></h2>
            </div>
            <div class="col-sm-1">
                <a href="logout.php"><b style="text-align:right">Logout</b></a>
            </div>
        </div>
        <div>
            <div style="float:right; margin-right:30px"><h6>Kyats in Mill.</h6></div>
        </div>
    <?php
  $res = mysqli_query($conn, "SELECT * FROM balance_sheet WHERE ref_id=".$_GET['id']);
  while ($row = mysqli_fetch_assoc($res)) {
  $res2 = mysqli_query($conn, "SELECT * FROM profit_loss WHERE ref_id=".$_GET['id']);
  while ($row12 = mysqli_fetch_assoc($res2)) {
    $res3 = mysqli_query($conn, "SELECT * FROM dscr_iscr WHERE ref_id=".$_GET['id']);
    while ($row13 = mysqli_fetch_assoc($res3)) {
    $liabilities = json_decode($row['liabilities']);
    $assets = json_decode($row['assets']);
    $data = json_decode($row12['data']);
    $dscr = json_decode($row13['dscr']);
    $iscr = json_decode($row13['iscr']);
    $TableHeader = json_decode($row['TableHeader']);
  ?>
    <table class="styled-table">
        <thead>
            <tr>
                <th></th>
                <th><?php echo $TableHeader->date[0]->value ?></th>
                <th><?php echo $TableHeader->date[1]->value ?></th>
                <th><?php echo $TableHeader->date[2]->value ?></th>
                <th><?php echo $TableHeader->date[3]->value ?></th>
                <th><?php echo $TableHeader->date[4]->value ?></th>
                <th><?php echo $TableHeader->date[5]->value ?></th>
            </tr>
            <tr>
                <th></th>
                <th><?php echo $TableHeader->heading[0]->value ?></th>
                <th><?php echo $TableHeader->heading[1]->value ?></th>
                <th><?php echo $TableHeader->heading[2]->value ?></th>
                <th><?php echo $TableHeader->heading[3]->value ?></th>
                <th><?php echo $TableHeader->heading[4]->value ?></th>
                <th><?php echo $TableHeader->heading[5]->value ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>Share Capital (Equity)</th>
                <?php
          foreach ($liabilities->CAPITAL_AND_RESERVE->bs_sc as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_sc<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_sc<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Net Worth</th>
                <?php
          $bs_gr = $liabilities->CAPITAL_AND_RESERVE->bs_gr;
          $bs_resd = $liabilities->CAPITAL_AND_RESERVE->bs_resd;
          foreach ($liabilities->CAPITAL_AND_RESERVE->bs_sc as $index =>  $row2) {
          ?>
                <td>
                    <input type="text" name="kf_nw<?php echo $row2->id; ?>"
                        value="<?php echo $row2->value + $bs_gr[$index]->value + $bs_resd[$index]->value; ?>"
                        id="kf_nw<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Net Block</th>
                <?php
          foreach ($assets->FIXED_ASSETS_AND_NON_CURRENT_ASSETS->bs_fanb as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_nb<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_nb<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Net Sales</th>
                <?php
          foreach ($data->Sales_Revenue->pal_tns as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_ns<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_ns<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Increase in Sales ( % age ) </th>
                <td>
                </td>
                <?php
          for ($i = 0; $i <= 4; $i++) {
          ?>
                <td>
                    <input name="kf_iis<?php echo $i + 1; ?>" id="kf_iis<?php echo $i + 1; ?>" value="0" type="text" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Net Profit</th>
                <?php
          foreach ($data->Net_Profit->pal_np as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_np<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_np<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Depreciation</th>
                <?php
          foreach ($data->Cost_of_Sales->pal_cosd as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_dp<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_dp<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Cash Accruals</th>
                <?php
          for ($i = 0; $i <= 5; $i++) {
          ?>
                <td>
                    <input name="kf_ca<?php echo $i+1; ?>" id="kf_ca<?php echo $i+1; ?>" value="0" type="text" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Profitability Ratio  PAT/Net Sales </th>
                <?php
          for ($i = 0; $i <= 5; $i++) {
          ?>
                <td>
                    <input name="kf_pr<?php echo $i+1; ?>" id="kf_pr<?php echo $i+1; ?>" value="0" type="text" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Return On Capital Employed (ROCE) </th>
                <?php
          for ($i = 0; $i <= 5; $i++) {
          ?>
                <td>
                    <input name="kf_roc<?php echo $i; ?>" id="kf_roc<?php echo $i; ?>" value="0" type="text" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Current Assets</th>
                <?php
          foreach ($assets->CURRENT_ASSETS->bs_tca as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_cas<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_cas<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Current Liabilities</th>
                <?php
          foreach ($liabilities->CURRENT_LIABILITIES->bs_tcl as $row2) {
          ?>
                <td>
                    <input type="text" name="kf_cl<?php echo $row2->id; ?>" value="<?php echo $row2->value; ?>"
                        id="kf_cl<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Current Ratio</th>
                <?php
          for ($i = 0; $i <= 5; $i++) {
          ?>
                <td>
                    <input name="kf_cr<?php echo $i+1; ?>" id="kf_cr<?php echo $i+1; ?>" value="0" type="text" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Debt/Equity Ratio </th>
                <?php
                $bs_tcl = $liabilities->CURRENT_LIABILITIES->bs_tcl;
                $bs_tmltl = $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_tmltl;
                foreach ($liabilities->CAPITAL_AND_RESERVE->bs_tcr as $index =>  $row2) {
                ?>
                        <td>
                            <input type="text" name="kf_nwDR<?php echo $row2->id; ?>"
                                value="<?php echo $row2->value != 0 ? ($bs_tcl[$index]->value + $bs_tmltl[$index]->value) / $row2->value : 0; ?>"
                                id="kf_nwDR<?php echo $row2->id; ?>" />
                        </td>
                        <?php
                }
                ?>
            </tr>
            <tr>
                <th>Debt Service Coverage Ratio (DSCR)</th>
                <td></td>
                <td></td>
                <?php
          foreach ($dscr->DSCR->dscr_dscr as $row2) {
          ?>
                <td>
                    <input type="text" id="dfs_cr<?php echo $row2->id; ?>" name="dfs_cr<?php echo $row2->id; ?>"
                        value="<?php echo $row2->value; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>DSCR ( Average )</th>
                <td></td>
                <td></td>
                <?php
          foreach ($dscr->Average_DSCR->dscr_avgdscr as $row2) {
          ?>
                <td>
                    <input type="text" id="kf_da" name="kf_da" value="<?php echo $row2->value; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Interest Service Coverage Ratio (ISCR)</th>
                <td></td>
                <td></td>
                <?php
          foreach ($iscr->iscr->iscr_iscr as $row2) {
          ?>
                <td>
                    <input type="text" id="kf_iscr<?php echo $row2->id; ?>" name="kf_iscr<?php echo $row2->id; ?>"
                        value="<?php echo $row2->value; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>ISCR ( Average )</th>
                <td></td>
                <td></td>
                <?php
          foreach ($iscr->Average_ISCR->iscr_avgiscr as $row2) {
          ?>
                <td>
                    <input type="text" id="kf_ia" name="kf_ia" value="<?php echo $row2->value; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
            <tr>
                <th>Debt Collection Period (Days)</th>
                <?php
          $bs_td = $assets->CURRENT_ASSETS->bs_td;
          foreach ($data->Sales_Revenue->pal_tns as $index =>  $row2) {
          ?>
                <td>
                    <input type="text" name="kf_nwDC<?php echo $row2->id; ?>"
                        value="<?php echo $row2->value != 0 ? $bs_td[$index]->value / $row2->value * 365 : 0; ?>"
                        id="kf_nwDC<?php echo $row2->id; ?>" />
                </td>
                <?php
          }
          ?>
            </tr>
        </tbody>
    </table>
    <?php
    }
  }
}
?>
<div class="my-2" id="bnts">
    <button class="btn btn-success" onclick="SaveAll(0)">Save All</button>
    <button class="btn btn-success" onclick="PrintAll(1)">Print</button>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
PrintAll = (e) => {
    SaveAll(e)
}
subFun = () => {
    let C10 = document.getElementById('kf_ns1').value;
    let D10 = document.getElementById('kf_ns2').value;
    let total1 =  (D10 - C10) / C10;
    document.getElementById('kf_iis1').value = total1.toFixed(2) * 100 + '%';

    let E10 = document.getElementById('kf_ns3').value;
    let total2 = (E10 - D10) / D10;
    document.getElementById('kf_iis2').value = total2.toFixed(2) * 100 + '%';

    let F10 = document.getElementById('kf_ns4').value;
    let total3 = (F10 - E10) / E10;
    document.getElementById('kf_iis3').value =  total3.toFixed(2) * 100 + '%';

    let G10 = document.getElementById('kf_ns5').value;
    let total4 = (G10 - F10) / F10;
    document.getElementById('kf_iis4').value =  total4.toFixed(2) * 100 + '%';

    let H10 = document.getElementById('kf_ns6').value;
    let total5 = (H10 - G10) / G10;
    document.getElementById('kf_iis5').value =  total5.toFixed(2) * 100 + '%';
}
subFun()

sumFun = () => {
    for (var x = 1; x <= 6; x++) {
        let C13 = parseFloat(document.getElementById(`kf_np${x}`).value);
        let C14 = parseFloat(document.getElementById(`kf_dp${x}`).value);
        let total = C13 + C14;
        document.getElementById(`kf_ca${x}`).value = total.toFixed(2);
    }
}
sumFun()
divFun = () => {
    for (var x = 1; x <= 6; x++) {
        let C13 = parseFloat(document.getElementById(`kf_np${x}`).value);
        let C10 = parseFloat(document.getElementById(`kf_ns${x}`).value);
        let total1 = C13 / C10;
        total1 *= 100;
        document.getElementById(`kf_pr${x}`).value = total1.toFixed(2) + '%';

        let C7 = parseFloat(document.getElementById(`kf_nw${x}`).value);
        let total2 = C13 / C7;
        total2 *= 100;
        document.getElementById(`kf_roc${x-1}`).value = total2.toFixed(2) + '%';

        let kf_cas = parseFloat(document.getElementById(`kf_cas${x}`).value);
        let kf_cl = parseFloat(document.getElementById(`kf_cl${x}`).value);
        let total3 = kf_cas / kf_cl;
        document.getElementById(`kf_cr${x}`).value = total3.toFixed(2);

        let DR = parseFloat(document.getElementById(`kf_nwDR${x}`).value);
        document.getElementById(`kf_nwDR${x}`).value = DR.toFixed(2)

        let DC = parseFloat(document.getElementById(`kf_nwDC${x}`).value);
        document.getElementById(`kf_nwDC${x}`).value = DC.toFixed()
    }
}
divFun()

function SaveAll(e) {
    var Key_Financial_and_Ratios = {
        Share_Capital: {
            kf_sc: []
        },
        Net_Worth: {
            kf_nw: []
        },
        Net_Block: {
            kf_nb: []
        },
        Net_Sales: {
            kf_ns: []
        },
        Increase_in_Sales: {
            kf_iis: []
        },
        Net_Profit: {
            kf_np: []
        },
        Depreciation: {
            kf_dp: []
        },
        Cash_Accruals: {
            kf_ca: []
        },
        Profitability_Ratio: {
            kf_pr: []
        },
        Current_Assets: {
            kf_cas: []
        },
        Return_On_Capital_Employed: {
            kf_roc: []
        },
        Current_Liabilities: {
            kf_cl: []
        },
        Current_Ratio: {
            kf_cr: []
        },
        Debt_Equity_Ratio: {
            kf_nwDR: []
        },
        Debt_Service_Coverage_Ratio: {
            dfs_cr: []
        },
        DSCR: {
            kf_da: []
        },
        Interest_Service_Coverage_Ratio: {
            kf_iscr: []
        },
        ISCR: {
            kf_ia: []
        },
        Debt_Collection_Period: {
            kf_nwDC: []
        },
    }

    for (var x = 1; x <= 6; x++) {
        Key_Financial_and_Ratios.Share_Capital.kf_sc.push({
            id: x,
            value: document.getElementById(`kf_sc${x}`).value,
        });
        Key_Financial_and_Ratios.Net_Worth.kf_nw.push({
            id: x,
            value: document.getElementById(`kf_nw${x}`).value,
        });
        Key_Financial_and_Ratios.Net_Block.kf_nb.push({
            id: x,
            value: document.getElementById(`kf_nb${x}`).value,
        });
        Key_Financial_and_Ratios.Net_Sales.kf_ns.push({
            id: x,
            value: document.getElementById(`kf_ns${x}`).value,
        });
        if (x <= 5) {
            Key_Financial_and_Ratios.Increase_in_Sales.kf_iis.push({
                id: x,
                value: document.getElementById(`kf_iis${x}`).value,
            });
        }
        Key_Financial_and_Ratios.Net_Profit.kf_np.push({
            id: x,
            value: document.getElementById(`kf_np${x}`).value,
        });
        Key_Financial_and_Ratios.Depreciation.kf_dp.push({
            id: x,
            value: document.getElementById(`kf_dp${x}`).value,
        });
        Key_Financial_and_Ratios.Cash_Accruals.kf_ca.push({
            id: x,
            value: document.getElementById(`kf_ca${x}`).value,
        });
        Key_Financial_and_Ratios.Profitability_Ratio.kf_pr.push({
            id: x,
            value: document.getElementById(`kf_pr${x}`).value,
        });
        Key_Financial_and_Ratios.Current_Assets.kf_cas.push({
            id: x,
            value: document.getElementById(`kf_cas${x}`).value,
        });
        Key_Financial_and_Ratios.Return_On_Capital_Employed.kf_roc.push({
            id: x,
            value: document.getElementById(`kf_roc${x-1}`).value,
        });
        Key_Financial_and_Ratios.Current_Liabilities.kf_cl.push({
            id: x,
            value: document.getElementById(`kf_cl${x}`).value,
        });
        Key_Financial_and_Ratios.Current_Ratio.kf_cr.push({
            id: x,
            value: document.getElementById(`kf_cr${x}`).value,
        });
        Key_Financial_and_Ratios.Debt_Equity_Ratio.kf_nwDR.push({
            id: x,
            value: document.getElementById(`kf_nwDR${x}`).value,
        });
        if (x <= 4) {
            Key_Financial_and_Ratios.Debt_Service_Coverage_Ratio.dfs_cr.push({
                id: x,
                value: document.getElementById(`dfs_cr${x}`).value,

            });
        }
        if (x <= 1) {
            Key_Financial_and_Ratios.DSCR.kf_da.push({
                id: x,
                value: document.getElementById(`kf_da`).value,
            });
        }
        if (x <= 4) {
            Key_Financial_and_Ratios.Interest_Service_Coverage_Ratio.kf_iscr.push({
                id: x,
                value: document.getElementById(`kf_iscr${x}`).value,
            });
        }
        if (x <= 1) {
            Key_Financial_and_Ratios.ISCR.kf_ia.push({
                id: x,
                value: document.getElementById(`kf_ia`).value,
            });
        }
        Key_Financial_and_Ratios.Debt_Collection_Period.kf_nwDC.push({
            id: x,
            value: document.getElementById(`kf_nwDC${x}`).value,
        });
    }
    console.log(Key_Financial_and_Ratios)
    $.post(
        "save.php", {
            action: "key",
            Key_Financial_and_Ratios: JSON.stringify(Key_Financial_and_Ratios),
            ref: <?php echo $_GET['id']; ?>
        },
        function(data, status) {
            console.log(data);
            if(e==1){
                window.location.href = "fpdf/index.php?id="+<?php echo $_GET['id']; ?>
            }else{
                window.location.href = 'index.php';
            }
        }
    );
}
</script>
</body>

</html>