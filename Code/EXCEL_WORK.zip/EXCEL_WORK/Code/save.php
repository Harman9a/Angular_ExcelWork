<?php
    include('config.php');

    if($_POST['action'] == 'BALANCE_SHEET'){
        $Liabilities = $_POST['Liabilities'];
        $Assets = $_POST['Assets'];
        $Balancing = $_POST['Balancing'];
        $ref = $_POST['ref'];
        $TableHeader = $_POST['TableHeader'];

        $check = mysqli_query($conn, "SELECT * FROM balance_sheet WHERE ref_id=".$ref); 

        if($check->num_rows != 0){
            mysqli_query($conn, "UPDATE balance_sheet SET liabilities='".$Liabilities."', assets='".$Assets."' , balancing='".$Balancing."' , TableHeader='".$TableHeader."'  WHERE ref_id='".$ref."'");
        }else{
            mysqli_query($conn, "INSERT into balance_sheet (ref_id,liabilities,assets,balancing,TableHeader) VALUES ('".$ref."','".$Liabilities."','".$Assets."','".$Balancing."','".$TableHeader."')");
        }
    }

    if($_POST['action'] == 'PROFIT_AND_LOSS'){
        $data = $_POST['data']; 
        $ref = $_POST['ref'];
        $TableHeader = $_POST['TableHeader'];

        
        $check = mysqli_query($conn, "SELECT * FROM profit_loss WHERE ref_id=".$ref);
        if($check->num_rows != 0){
           $res =  mysqli_query($conn, "UPDATE profit_loss SET data='".$data."' , TableHeader='".$TableHeader."' WHERE ref_id='".$ref."'");
        }else{
            mysqli_query($conn, "INSERT into profit_loss (ref_id,data,TableHeader) VALUES ('".$ref."','".$data."','".$TableHeader."')");
        }
    }

    if($_POST['action'] == 'DSCR_AND_ISCR'){
        $dscr = $_POST['dscr'];
        $iscr = $_POST['iscr'];
        $ref = $_POST['ref'];
        $TableHeader = $_POST['TableHeader'];

        $check = mysqli_query($conn, "SELECT * FROM dscr_iscr WHERE ref_id=".$ref);

        if($check->num_rows != 0){
            mysqli_query($conn, "UPDATE dscr_iscr SET dscr='".$dscr."' , iscr='".$iscr."' , TableHeader='".$TableHeader."' WHERE ref_id='".$ref."'");
        }else{
            mysqli_query($conn, "INSERT into dscr_iscr (ref_id,dscr,iscr,TableHeader) VALUES ('".$ref."','".$dscr."','".$iscr."','".$TableHeader."')");
        }
    }
    
    if($_POST['action'] == 'key'){
        $data = $_POST['Key_Financial_and_Ratios'];
        $ref = $_POST['ref'];
        $check = mysqli_query($conn, "SELECT * FROM key_financial_and_ratios WHERE ref_id=".$ref); 

        if($check->num_rows != 0){
            mysqli_query($conn, "UPDATE key_financial_and_ratios SET data='".$data."' WHERE ref_id='".$ref."'");
        }else{
            $res = mysqli_query($conn, "INSERT into key_financial_and_ratios (ref_id,data) VALUES ('".$ref."','".$data."')");
        }
    }
?>