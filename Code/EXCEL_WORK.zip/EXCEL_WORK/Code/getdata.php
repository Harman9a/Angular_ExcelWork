<?php
error_reporting(0);

header("Access-Control-Allow-Origin: *");
// header('Access-Control-Allow-Credentials: true');
// header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
// header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
// header("Content-Type: application/json; charset=UTF-8");

$DB_host = "localhost";
    $DB_user = "root";
    $DB_pass = "wordpress";
   

    $DB_name = "excel_work";
    $conn = mysqli_connect($DB_host , $DB_user , $DB_pass ,$DB_name );
if($_GET['id'] != ''){
   $res = mysqli_query($conn, "SELECT * FROM test WHERE c_id=".$_GET['id']);
   while ($row = mysqli_fetch_assoc($res)) {
      echo $row['data'];
   }

}
if($_GET['cid'] != ''){
   $c_res = mysqli_query($conn, "SELECT * FROM Companies WHERE id=".$_GET['cid']);
   while ($c_row = mysqli_fetch_assoc($c_res)) {
    $response[] = $c_row;
   }
   echo json_encode($response);
}


if($_GET['pfid'] != ''){
   $res_pf = mysqli_query($conn, "SELECT * FROM profitloss WHERE c_id=".$_GET['pfid']);
   while ($rowpf = mysqli_fetch_assoc($res_pf)) {
      echo $rowpf['data'];
   }

}

   
if($_GET['di'] != ''){
   $res_di = mysqli_query($conn, "SELECT * FROM ds_is WHERE c_id=".$_GET['di']);
   while ($rowdi = mysqli_fetch_assoc($res_di)) {
      echo $rowdi['dscr'];

   }

}

   
if($_GET['is'] != ''){
   $res_is = mysqli_query($conn, "SELECT * FROM iscr WHERE c_id=".$_GET['is']);
   while ($rowis = mysqli_fetch_assoc($res_is)) {
      echo $rowis['iscr'];

   }

}
    ?>