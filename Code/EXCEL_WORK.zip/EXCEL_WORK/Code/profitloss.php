<?php include('config.php');
session_start();

if(!isset($_SESSION['id'])){
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <style>
        @page { margin: 0; }
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 5px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }

    .styled-table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }

    .heading {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-size: 0.9em;
        font-family: sans-serif;
        padding: 12px 15px;
    }
    .hInput{
        background-color: #029879;
        border: 1px solid white;
        color: white;
    }
    </style>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
</head>

<body>

    <div class="row">
        <div class="col-sm-4">
                <h2>Profit and Loss</h2>
            </div>
            <div class="col-sm-7">
                <h2>Company Name: <?php echo $_SESSION['company_name']; ?></h2>
            </div>
            <div class="col-sm-1">
                <a href="logout.php"><b style="text-align:right">Logout</b></a>

            </div>
        </div>
        <div>
            <div style="float:right; margin-right:30px"><h6>Kyats in Mill.</h6></div>
        </div>
    <?php
$result = mysqli_query($conn, "SELECT * FROM profit_loss WHERE ref_id=".$_GET['id']);
$res3 = mysqli_query($conn, "SELECT * FROM balance_sheet WHERE ref_id=".$_GET['id']);
if($result->num_rows == 0){
?>


    <table class="styled-table">
        <thead>
            <tr>
                <th>Profit and Loss Account</th>
            </tr>
            <tr>
                <?php while ($row3 = mysqli_fetch_assoc($res3)) { 
                $date = json_decode($row3['TableHeader']);    
                ?>
                    <th></th>
                    <th><input id="date1" class='hInput' type="text" value="<?php echo $date->date[0]->value; ?>" /></th>
                    <th><input id="date2" class='hInput' type="text" value="<?php echo $date->date[1]->value; ?>" /></th>
                    <th><input id="date3" class='hInput' type="text" value="<?php echo $date->date[2]->value; ?>" /></th>
                    <th><input id="date4" class='hInput' type="text" value="<?php echo $date->date[3]->value; ?>" /></th>
                    <th><input id="date5" class='hInput' type="text" value="<?php echo $date->date[4]->value; ?>" /></th>
                    <th><input id="date6" class='hInput' type="text" value="<?php echo $date->date[5]->value; ?>" /></th>
                </tr>
                <tr>
                <th></th>
                <th><input id="head1" class='hInput' type="text" value="<?php echo $date->heading[0]->value; ?>" /></th>
                <th><input id="head2" class='hInput' type="text" value="<?php echo $date->heading[1]->value; ?>" /></th>
                <th><input id="head3" class='hInput' type="text" value="<?php echo $date->heading[2]->value; ?>" /></th>
                <th><input id="head4" class='hInput' type="text" value="<?php echo $date->heading[3]->value; ?>" /></th>
                <th><input id="head5" class='hInput' type="text" value="<?php echo $date->heading[4]->value; ?>" /></th>
                <th><input id="head6" class='hInput' type="text" value="<?php echo $date->heading[5]->value; ?>" /></th>
                <?php } ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>Sales / Revenue</th>
            </tr>
            <tr>
                <th>Domestic</th>
                <td>
                    <input type="text" name="pal_d1" value="0" id="pal_d1" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" name="pal_d2" value="0" id="pal_d2" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" name="pal_d3" value="0" id="pal_d3" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" name="pal_d4" value="0" id="pal_d4" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" name="pal_d5" value="0" id="pal_d5" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" name="pal_d6" value="0" id="pal_d6" onkeyup="sum_sr()" />
                </td>
            </tr>
            <tr>
                <th>Exports</th>
                <td>
                    <input value="0" type="text" name="pal_e1" id="pal_e1" onkeyup="sum_sr()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_e2" onkeyup="sum_sr()" name="pal_e2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_e3" onkeyup="sum_sr()" name="pal_e3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_e4" onkeyup="sum_sr()" name="pal_e4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_e5" onkeyup="sum_sr()" name="pal_bli5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_e6" onkeyup="sum_sr()" name="pal_e6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Total Net Sales</th>
                <td>
                    <input type="text" name="pal_tns1" value="0" id="pal_tns1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_tns2" value="0" id="pal_tns2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_tns3" value="0" id="pal_tns3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_tns4" value="0" id="pal_tns4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_tns5" value="0" id="pal_tns5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_tns6" value="0" id="pal_tns6" disabled />
                </td>
            </tr>
            <tr>
                <th>Cost of Sales</th>
            </tr>
            <tr>
                <th>Raw Material / Stocks Purchased</th>
                <td>
                    <input type="text" name="pal_rmsp1" value="0" id="pal_rmsp1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" name="pal_rmsp2" value="0" id="pal_rmsp2" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" name="pal_rmsp3" value="0" id="pal_rmsp3" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" name="pal_rmsp4" value="0" id="pal_rmsp4" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" name="pal_rmsp5" value="0" id="pal_rmsp5" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" name="pal_rmsp6" value="0" id="pal_rmsp6" onkeyup="sum_cos()" />
                </td>
            </tr>
            <tr>
                <th>Other Spares</th>
                <td>
                    <input value="0" type="text" name="pal_os1" id="pal_os1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_os2" onkeyup="sum_cos()" name="pal_os2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_os3" onkeyup="sum_cos()" name="pal_os3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_os4" onkeyup="sum_cos()" name="pal_os4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_os5" onkeyup="sum_cos()" name="pal_os5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_os6" onkeyup="sum_cos()" name="pal_os6" />
                </td>
            </tr>
            <tr>
                <th>Power & Fuel</th>
                <td>
                    <input value="0" type="text" name="pal_pf1" id="pal_pf1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_pf2" onkeyup="sum_cos()" name="pal_pf2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_pf3" onkeyup="sum_cos()" name="pal_pf3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_pf4" onkeyup="sum_cos()" name="pal_pf4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_pf5" onkeyup="sum_cos()" name="pal_pf5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_pf6" onkeyup="sum_cos()" name="pal_pf6" />
                </td>
            </tr>
            <tr>
                <th>Direct Labour Charges</th>
                <td>
                    <input value="0" type="text" name="pal_dlc1" id="pal_dlc1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dlc2" onkeyup="sum_cos()" name="pal_dlc2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dlc3" onkeyup="sum_cos()" name="pal_dlc3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dlc4" onkeyup="sum_cos()" name="pal_dlc4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dlc5" onkeyup="sum_cos()" name="pal_dlc5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dlc6" onkeyup="sum_cos()" name="pal_dlc6" />
                </td>
            </tr>
            <tr>
                <th>Rentals (Factory and Godowns)</th>
                <td>
                    <input value="0" type="text" name="pal_rfag1" id="pal_rfag1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_rfag2" onkeyup="sum_cos()" name="pal_rfag2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_rfag3" onkeyup="sum_cos()" name="pal_rfag3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_rfag4" onkeyup="sum_cos()" name="pal_rfag4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_rfag5" onkeyup="sum_cos()" name="pal_rfag5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_rfag6" onkeyup="sum_cos()" name="pal_rfag6" />
                </td>
            </tr>
            <tr>
                <th>Depreciation.</th>
                <td>
                    <input value="0" type="text" name="pal_cosd1" id="pal_cosd1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_cosd2" onkeyup="sum_cos()" name="pal_cosd2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_cosd3" onkeyup="sum_cos()" name="pal_cosd3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_cosd4" onkeyup="sum_cos()" name="pal_cosd4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_cosd5" onkeyup="sum_cos()" name="pal_cosd5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_cosd6" onkeyup="sum_cos()" name="pal_cosd6" />
                </td>
            </tr>
            <tr>
                <th>Other Direct Expenses</th>
                <td>
                    <input value="0" type="text" name="pal_ode1" id="pal_ode1" onkeyup="sum_cos()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_ode2" onkeyup="sum_cos()" name="pal_ode2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_ode3" onkeyup="sum_cos()" name="pal_ode3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_ode4" onkeyup="sum_cos()" name="pal_ode4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_ode5" onkeyup="sum_cos()" name="pal_ode5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_ode6" onkeyup="sum_cos()" name="pal_ode6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <td>
                    <input type="text" name="pal_stcos1" value="0" id="pal_stcos1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcos2" value="0" id="pal_stcos2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcos3" value="0" id="pal_stcos3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcos4" value="0" id="pal_stcos4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcos5" value="0" id="pal_stcos5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcos6" value="0" id="pal_stcos6" disabled />
                </td>
            </tr>
            <tr>
                <th>Add : Opening stocks</th>
                <td>
                    <input value="0" type="text" name="pal_aos1" id="pal_aos1" onkeyup="sum_cop()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_aos2" onkeyup="sum_cop()" name="pal_aos2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_aos3" onkeyup="sum_cop()" name="pal_aos3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_aos4" onkeyup="sum_cop()" name="pal_aos4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_aos5" onkeyup="sum_cop()" name="pal_aos5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_aos6" onkeyup="sum_cop()" name="pal_aos6" />
                </td>
            </tr>
            <tr>
                <th>Deduct : Closing Stocks.</th>
                <td>
                    <input value="0" type="text" name="pal_dcs1" id="pal_dcs1" onkeyup="sum_cop()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dcs2" onkeyup="sum_cop()" name="pal_dcs2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dcs3" onkeyup="sum_cop()" name="pal_dcs3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dcs4" onkeyup="sum_cop()" name="pal_dcs4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dcs5" onkeyup="sum_cop()" name="pal_dcs5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_dcs6" onkeyup="sum_cop()" name="pal_dcs6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Cost of Production :</th>
                <td>
                    <input type="text" name="pal_stcop1" value="0" id="pal_stcop1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcop2" value="0" id="pal_stcop2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcop3" value="0" id="pal_stcop3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcop4" value="0" id="pal_stcop4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcop5" value="0" id="pal_stcop5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stcop6" value="0" id="pal_stcop6" disabled />
                </td>
            </tr>
            <tr>
                <th>General and Admin. Expneses</th>
                <td>
                    <input value="0" type="text" name="pal_gaae1" id="pal_gaae1" onkeyup="sum_cosf()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_gaae2" onkeyup="sum_cosf()" name="pal_gaae2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_gaae3" onkeyup="sum_cosf()" name="pal_gaae3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_gaae4" onkeyup="sum_cosf()" name="pal_gaae4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_gaae5" onkeyup="sum_cosf()" name="pal_gaae5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_gaae6" onkeyup="sum_cosf()" name="pal_gaae6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Cost of Sales :</th>
                <td>
                    <input type="text" name="pal_cosT1" value="0" id="pal_cosT1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_cosT2" value="0" id="pal_cosT2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_cosT3" value="0" id="pal_cosT3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_cosT4" value="0" id="pal_cosT4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_cosT5" value="0" id="pal_cosT5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_cosT6" value="0" id="pal_cosT6" disabled />
                </td>
            </tr>
            <tr></tr>
            <tr>
                <td></td>
            </tr>
            <br />
            <tr style="background-color: #009879">
                <th>Operating Profit :</th>
                <td>
                    <input type="text" name="pal_op1" value="0" id="pal_op1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_op2" value="0" id="pal_op2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_op3" value="0" id="pal_op3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_op4" value="0" id="pal_op4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_op5" value="0" id="pal_op5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_op6" value="0" id="pal_op6" disabled />
                </td>
            </tr>

            <tr>
                <th>Non-Operating Expenses</th>
            </tr>
            <tr>
                <th>Interest on Bank Borrowings</th>
                <td>
                    <input type="text" name="pal_inbb1" value="0" id="pal_inbb1" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" name="pal_inbb2" value="0" id="pal_inbb2" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" name="pal_inbb3" value="0" id="pal_inbb3" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" name="pal_inbb4" value="0" id="pal_inbb4" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" name="pal_inbb5" value="0" id="pal_inbb5" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" name="pal_inbb6" value="0" id="pal_inbb6" onkeyup="sum_noe()" />
                </td>
            </tr>
            <tr>
                <th>Interest on Loans from Others.</th>
                <td>
                    <input value="0" type="text" name="pal_iolfo1" id="pal_iolfo1" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_iolfo2" onkeyup="sum_noe()" name="pal_iolfo2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_iolfo3" onkeyup="sum_noe()" name="pal_iolfo3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_iolfo4" onkeyup="sum_noe()" name="pal_iolfo4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_iolfo5" onkeyup="sum_noe()" name="pal_iolfo5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_iolfo6" onkeyup="sum_noe()" name="pal_iolfo6" />
                </td>
            </tr>
            <tr>
                <th>Other Non-Operating Expenses</th>
                <td>
                    <input value="0" type="text" name="pal_onoe1" id="pal_onoe1" onkeyup="sum_noe()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoe2" onkeyup="sum_noe()" name="pal_onoe2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoe3" onkeyup="sum_noe()" name="pal_onoe3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoe4" onkeyup="sum_noe()" name="pal_onoe4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoe5" onkeyup="sum_noe()" name="pal_onoe5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoe6" onkeyup="sum_noe()" name="pal_onoe6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <td>
                    <input type="text" name="pal_stnoe1" value="0" id="pal_stnoe1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoe2" value="0" id="pal_stnoe2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoe3" value="0" id="pal_stnoe3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoe4" value="0" id="pal_stnoe4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoe5" value="0" id="pal_stnoe5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoe6" value="0" id="pal_stnoe6" disabled />
                </td>
            </tr>

            <tr>
                <th>Non-Operating Income</th>
            </tr>
            <tr>
                <th>Interest Income.</th>
                <td>
                    <input type="text" name="pal_ii1" value="0" id="pal_ii1" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" name="pal_ii2" value="0" id="pal_ii2" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" name="pal_ii3" value="0" id="pal_ii3" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" name="pal_ii4" value="0" id="pal_ii4" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" name="pal_ii5" value="0" id="pal_ii5" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" name="pal_ii6" value="0" id="pal_ii6" onkeyup="sum_noi()" />
                </td>
            </tr>
            <tr>
                <th>Other Non-Operating Income</th>
                <td>
                    <input value="0" type="text" name="pal_onoi1" id="pal_onoi1" onkeyup="sum_noi()" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoi2" onkeyup="sum_noi()" name="pal_onoi2" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoi3" onkeyup="sum_noi()" name="pal_onoi3" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoi4" onkeyup="sum_noi()" name="pal_onoi4" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoi5" onkeyup="sum_noi()" name="pal_onoi5" />
                </td>
                <td>
                    <input type="text" value="0" id="pal_onoi6" onkeyup="sum_noi()" name="pal_onoi6" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <td>
                    <input type="text" name="pal_stnoi1" value="0" id="pal_stnoi1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoi2" value="0" id="pal_stnoi2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoi3" value="0" id="pal_stnoi3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoi4" value="0" id="pal_stnoi4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoi5" value="0" id="pal_stnoi5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_stnoi6" value="0" id="pal_stnoi6" disabled />
                </td>
            </tr>

            <tr></tr>
            <tr>
                <td></td>
            </tr>
            <br />
            <tr style="background-color: #009879">
                <th>Profit before Taxes :</th>
                <td>
                    <input type="text" name="pal_pbt1" value="0" id="pal_pbt1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_pbt2" value="0" id="pal_pbt2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_pbt3" value="0" id="pal_pbt3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_pbt4" value="0" id="pal_pbt4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_pbt5" value="0" id="pal_pbt5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_pbt6" value="0" id="pal_pbt6" disabled />
                </td>
            </tr>

            <tr>
                <th>Provision for taxation</th>
                <td>
                    <input type="text" name="pal_pft1" value="0" id="pal_pft1" onkeyup="sum_np()" />
                </td>
                <td>
                    <input type="text" name="pal_pft2" value="0" id="pal_pft2" onkeyup="sum_np()" />
                </td>
                <td>
                    <input type="text" name="pal_pft3" value="0" id="pal_pft3" onkeyup="sum_np()" />
                </td>
                <td>
                    <input type="text" name="pal_pft4" value="0" id="pal_pft4" onkeyup="sum_np()" />
                </td>
                <td>
                    <input type="text" name="pal_pft5" value="0" id="pal_pft5" onkeyup="sum_np()" />
                </td>
                <td>
                    <input type="text" name="pal_pft6" value="0" id="pal_pft6" onkeyup="sum_np()" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Net Profit :</th>
                <td>
                    <input type="text" name="pal_np1" value="0" id="pal_np1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_np2" value="0" id="pal_np2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_np3" value="0" id="pal_np3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_np4" value="0" id="pal_np4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_np5" value="0" id="pal_np5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_np6" value="0" id="pal_np6" disabled />
                </td>
            </tr>
            <tr>
                <th>Dividend / Withdrawals</th>
                <td>
                    <input type="text" name="pal_dw1" value="0" id="pal_dw1" onkeyup="sum_rp()" />
                </td>
                <td>
                    <input type="text" name="pal_dw2" value="0" id="pal_dw2" onkeyup="sum_rp()" />
                </td>
                <td>
                    <input type="text" name="pal_dw3" value="0" id="pal_dw3" onkeyup="sum_rp()" />
                </td>
                <td>
                    <input type="text" name="pal_dw4" value="0" id="pal_dw4" onkeyup="sum_rp()" />
                </td>
                <td>
                    <input type="text" name="pal_dw5" value="0" id="pal_dw5" onkeyup="sum_rp()" />
                </td>
                <td>
                    <input type="text" name="pal_dw6" value="0" id="pal_dw6" onkeyup="sum_rp()" />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Retained profit</th>
                <td>
                    <input type="text" name="pal_rp1" value="0" id="pal_rp1" disabled />
                </td>
                <td>
                    <input type="text" name="pal_rp2" value="0" id="pal_rp2" disabled />
                </td>
                <td>
                    <input type="text" name="pal_rp3" value="0" id="pal_rp3" disabled />
                </td>
                <td>
                    <input type="text" name="pal_rp4" value="0" id="pal_rp4" disabled />
                </td>
                <td>
                    <input type="text" name="pal_rp5" value="0" id="pal_rp5" disabled />
                </td>
                <td>
                    <input type="text" name="pal_rp6" value="0" id="pal_rp6" disabled />
                </td>
            </tr>
        </tbody>
    </table>


    <?php
}else{
while($row = mysqli_fetch_assoc($result))
{
  $data = json_decode($row['data']);
  $TableHeader = json_decode($row['TableHeader'])
          ?>
    <table class="styled-table">
        <thead>
            <tr>
                <th>Profit and Loss Account</th>
            </tr>
            <tr>
                <th></th>
                <th><input id="date1" class='hInput' type="text" value="<?php echo $TableHeader->date[0]->value ?>" /></th>
                <th><input id="date2" class='hInput' type="text" value="<?php echo $TableHeader->date[1]->value ?>" /></th>
                <th><input id="date3" class='hInput' type="text" value="<?php echo $TableHeader->date[2]->value ?>" /></th>
                <th><input id="date4" class='hInput' type="text" value="<?php echo $TableHeader->date[3]->value ?>" /></th>
                <th><input id="date5" class='hInput' type="text" value="<?php echo $TableHeader->date[4]->value ?>" /></th>
                <th><input id="date6" class='hInput' type="text" value="<?php echo $TableHeader->date[5]->value ?>" /></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="head1" class='hInput' type="text" value="<?php echo $TableHeader->heading[0]->value ?>" /></th>
                <th><input id="head2" class='hInput' type="text" value="<?php echo $TableHeader->heading[1]->value ?>" /></th>
                <th><input id="head3" class='hInput' type="text" value="<?php echo $TableHeader->heading[2]->value ?>" /></th>
                <th><input id="head4" class='hInput' type="text" value="<?php echo $TableHeader->heading[3]->value ?>" /></th>
                <th><input id="head5" class='hInput' type="text" value="<?php echo $TableHeader->heading[4]->value ?>" /></th>
                <th><input id="head6" class='hInput' type="text" value="<?php echo $TableHeader->heading[5]->value ?>" /></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>Sales / Revenue</th>
            </tr>
            <tr>
                <th>Domestic</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_d<?php echo $i+1; ?>"
                        value="<?php echo $data->Sales_Revenue->pal_d[$i]->value; ?>" id="pal_d<?php echo $i+1; ?>"
                        onkeyup="sum_sr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Exports</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_e<?php echo $i+1; ?>"
                        value="<?php echo $data->Sales_Revenue->pal_e[$i]->value; ?>" id="pal_e<?php echo $i+1; ?>"
                        onkeyup="sum_sr()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Total Net Sales</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_tns<?php echo $i+1; ?>"
                        value="<?php echo $data->Sales_Revenue->pal_tns[$i]->value; ?>" id="pal_tns<?php echo $i+1; ?>"
                        onkeyup="sum_sr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Cost of Sales</th>
            </tr>
            <tr>
                <th>Raw Material / Stocks Purchased</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_rmsp<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_rmsp[$i]->value; ?>"
                        id="pal_rmsp<?php echo $i+1; ?>" onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Spares</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_os<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_os[$i]->value; ?>" id="pal_os<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Power & Fuel</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_pf<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_pf[$i]->value; ?>" id="pal_pf<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Direct Labour Charges</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_dlc<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_dlc[$i]->value; ?>" id="pal_dlc<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Rentals (Factory and Godowns)</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_rfag<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_rfag[$i]->value; ?>"
                        id="pal_rfag<?php echo $i+1; ?>" onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Depreciation.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_cosd<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_cosd[$i]->value; ?>"
                        id="pal_cosd<?php echo $i+1; ?>" onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Direct Expenses</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_ode<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_ode[$i]->value; ?>" id="pal_ode<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_stcos<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_stcos[$i]->value; ?>"
                        id="pal_stcos<?php echo $i+1; ?>" onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Add : Opening stocks</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_aos<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_aos[$i]->value; ?>" id="pal_aos<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Deduct : Closing Stocks.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_dcs<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Sales->pal_dcs[$i]->value; ?>" id="pal_dcs<?php echo $i+1; ?>"
                        onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Cost of Production :</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_stcop<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_Production->pal_stcop[$i]->value; ?>"
                        id="pal_stcop<?php echo $i+1; ?>" onkeyup="sum_cos()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>General and Admin. Expneses</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_gaae<?php echo $i+1; ?>"
                        value="<?php echo $data->General_and_Admin_Expneses->pal_gaae[$i]->value; ?>"
                        id="pal_gaae<?php echo $i+1; ?>" nkeyup="sum_cosf()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Cost of Sales :</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_cosT<?php echo $i+1; ?>"
                        value="<?php echo $data->Cost_of_SalesT->pal_cosT[$i]->value; ?>"
                        id="pal_cosT<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
            <tr></tr>
            <tr>
                <td></td>
            </tr>
            <br />
            <tr style="background-color: #009879">
                <th>Operating Profit :</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_op<?php echo $i+1; ?>"
                        value="<?php echo $data->Operating_Profit->pal_op[$i]->value; ?>"
                        id="pal_op<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>

            <tr>
                <th>Non-Operating Expenses</th>
            </tr>
            <tr>
                <th>Interest on Bank Borrowings</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_inbb<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Expenses->pal_inbb[$i]->value; ?>"
                        id="pal_inbb<?php echo $i+1; ?>" onkeyup="sum_noe()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Interest on Loans from Others.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_iolfo<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Expenses->pal_iolfo[$i]->value; ?>"
                        id="pal_iolfo<?php echo $i+1; ?>" onkeyup="sum_noe()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Non-Operating Expenses</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_onoe<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Expenses->pal_onoe[$i]->value; ?>"
                        id="pal_onoe<?php echo $i+1; ?>" onkeyup="sum_noe()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_stnoe<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Expenses->pal_stnoe[$i]->value; ?>"
                        id="pal_stnoe<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>

            <tr>
                <th>Non-Operating Income</th>
            </tr>
            <tr>
                <th>Interest Income.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_ii<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Income->pal_ii[$i]->value; ?>"
                        id="pal_ii<?php echo $i+1; ?>" onkeyup="sum_noi()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Non-Operating Income</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_onoi<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Income->pal_onoi[$i]->value; ?>"
                        id="pal_onoi<?php echo $i+1; ?>" onkeyup="sum_noi()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Sub-Total</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_stnoi<?php echo $i+1; ?>"
                        value="<?php echo $data->Non_Operating_Income->pal_stnoi[$i]->value; ?>"
                        id="pal_stnoi<?php echo $i+1; ?>" onkeyup="sum_noi()" />
                </td>
                <?php } ?>
            </tr>

            <tr></tr>
            <tr>
                <td></td>
            </tr>
            <br />
            <tr style="background-color: #009879">
                <th>Profit before Taxes :</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_pbt<?php echo $i+1; ?>"
                        value="<?php echo $data->Profit_before_Taxes->pal_pbt[$i]->value; ?>"
                        id="pal_pbt<?php echo $i+1; ?>" onkeyup="sum_np()" />
                </td>
                <?php } ?>
            </tr>

            <tr>
                <th>Provision for taxation</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_pft<?php echo $i+1; ?>"
                        value="<?php echo $data->Provision_for_taxation->pal_pft[$i]->value; ?>"
                        id="pal_pft<?php echo $i+1; ?>" onkeyup="sum_np()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Net Profit :</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_np<?php echo $i+1; ?>"
                        value="<?php echo $data->Net_Profit->pal_np[$i]->value; ?>" id="pal_np<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Dividend / Withdrawals</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_dw<?php echo $i+1; ?>"
                        value="<?php echo $data->Dividend_Withdrawals->pal_dw[$i]->value; ?>"
                        id="pal_dw<?php echo $i+1; ?>" onkeyup="sum_rp()" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Retained profit</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="pal_rp<?php echo $i+1; ?>"
                        value="<?php echo $data->Retained_profit->pal_rp[$i]->value; ?>"
                        id="pal_rp<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
        </tbody>
    </table>
    <?php 
   }
  }
  ?>
<div class="my-2" id="bnts">
    <button class="btn btn-success" onclick="saveAll()">Next (DSCR-ISCR)</button>
    <button class="btn btn-success" onclick="PrintAll()">Print</button>
</div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script type="text/javascript">
    PrintAll = () => {
        document.getElementById('bnts').style.display = 'none';
        window.print();
        document.getElementById('bnts').style.display = 'block';
    }
    function sum_sr() {
        for (var x = 1; x <= 6; x++) {
            var pal_d = parseFloat(document.getElementById(`pal_d${x}`).value);
            var pal_e = parseFloat(document.getElementById(`pal_e${x}`).value);

            let total = pal_d + pal_e;
            document.getElementById(`pal_tns${x}`).value = total.toFixed(2);
        }
        sum_op();
    }

    function sum_cos() {
        for (var x = 1; x <= 6; x++) {
            var pal_rmsp = parseFloat(
                document.getElementById(`pal_rmsp${x}`).value
            );
            var pal_os = parseFloat(document.getElementById(`pal_os${x}`).value);
            var pal_pf = parseFloat(document.getElementById(`pal_pf${x}`).value);
            var pal_dlc = parseFloat(document.getElementById(`pal_dlc${x}`).value);
            var pal_rfag = parseFloat(
                document.getElementById(`pal_rfag${x}`).value
            );
            var pal_cosd = parseFloat(
                document.getElementById(`pal_cosd${x}`).value
            );
            var pal_ode = parseFloat(document.getElementById(`pal_ode${x}`).value);

            let total = pal_rmsp + pal_os + pal_pf + pal_dlc + pal_rfag + pal_cosd + pal_ode;
            document.getElementById(`pal_stcos${x}`).value = total.toFixed(2);
        }
        sum_cop();
    }

    function sum_cop() {
        for (var x = 1; x <= 6; x++) {
            var pal_stcos = parseFloat(
                document.getElementById(`pal_stcos${x}`).value
            );
            var pal_aos = parseFloat(document.getElementById(`pal_aos${x}`).value);
            var pal_dcs = parseFloat(document.getElementById(`pal_dcs${x}`).value);

            let total = pal_stcos + pal_aos - pal_dcs;
            document.getElementById(`pal_stcop${x}`).value = total.toFixed(2);
        }
        sum_cosf();
    }

    function sum_cosf() {
        for (var x = 1; x <= 6; x++) {
            var pal_stcop = parseFloat(
                document.getElementById(`pal_stcop${x}`).value
            );

            var pal_gaae = parseFloat(
                document.getElementById(`pal_gaae${x}`).value
            );

            let total = pal_stcop + pal_gaae;
            document.getElementById(`pal_cosT${x}`).value = total.toFixed(2);
        }
        sum_op();
    }

    function sum_op() {
        for (var x = 1; x <= 6; x++) {
            var pal_tns = parseFloat(document.getElementById(`pal_tns${x}`).value);

            var pal_cos = parseFloat(document.getElementById(`pal_cosT${x}`).value);
            let total = pal_tns - pal_cos;
            document.getElementById(`pal_op${x}`).value = total.toFixed(2);
        }
        sum_pbt();
    }

    function sum_noe() {
        for (var x = 1; x <= 6; x++) {
            var pal_inbb = parseFloat(
                document.getElementById(`pal_inbb${x}`).value
            );
            var pal_iolfo = parseFloat(
                document.getElementById(`pal_iolfo${x}`).value
            );
            var pal_onoe = parseFloat(
                document.getElementById(`pal_onoe${x}`).value
            );

            let total = pal_inbb + pal_iolfo + pal_onoe;
            document.getElementById(`pal_stnoe${x}`).value = total.toFixed(2);
        }
        sum_pbt();
    }

    function sum_noi() {
        for (var x = 1; x <= 6; x++) {
            var pal_ii = parseFloat(document.getElementById(`pal_ii${x}`).value);
            var pal_onoi = parseFloat(
                document.getElementById(`pal_onoi${x}`).value
            );
            let total = pal_ii + pal_onoi;
            document.getElementById(`pal_stnoi${x}`).value = total.toFixed(2);
        }
        sum_pbt();
    }

    function sum_pbt() {
        for (var x = 1; x <= 6; x++) {
            var pal_op = parseFloat(document.getElementById(`pal_op${x}`).value);
            var pal_stnoi = parseFloat(
                document.getElementById(`pal_stnoi${x}`).value
            );
            var pal_stnoe = parseFloat(
                document.getElementById(`pal_stnoe${x}`).value
            );

            let total = (pal_op - pal_stnoe) + pal_stnoi;
            document.getElementById(`pal_pbt${x}`).value = total.toFixed(2);
        }
        sum_np();
    }

    function sum_np() {
        for (var x = 1; x <= 6; x++) {
            var pal_pbt = parseFloat(document.getElementById(`pal_pbt${x}`).value);
            var pal_pft = parseFloat(document.getElementById(`pal_pft${x}`).value);

            let total = pal_pbt - pal_pft;
            document.getElementById(`pal_np${x}`).value = total.toFixed(2);
        }
        sum_rp();
    }

    function sum_rp() {
        for (var x = 1; x <= 6; x++) {
            var pal_np = parseFloat(document.getElementById(`pal_np${x}`).value);
            var pal_dw = parseFloat(document.getElementById(`pal_dw${x}`).value);

            let total = pal_np - pal_dw;
            document.getElementById(`pal_rp${x}`).value = total.toFixed(2);
        }
    }
    saveAll = () => {
        let Profit_and_Loss = {
            Sales_Revenue: {
                pal_d: [],
                pal_e: [],
                pal_tns: [],
            },
            Cost_of_Sales: {
                pal_rmsp: [],
                pal_os: [],
                pal_pf: [],
                pal_dlc: [],
                pal_rfag: [],
                pal_cosd: [],
                pal_ode: [],
                pal_stcos: [],
                pal_aos: [],
                pal_dcs: [],
            },
            Cost_of_Production: {
                pal_stcop: [],
            },
            General_and_Admin_Expneses: {
                pal_gaae: [],
            },
            Cost_of_SalesT: {
                pal_cosT: [],
            },
            Operating_Profit: {
                pal_op: [],
            },
            Non_Operating_Expenses: {
                pal_inbb: [],
                pal_iolfo: [],
                pal_onoe: [],
                pal_stnoe: [],
            },
            Non_Operating_Income: {
                pal_ii: [],
                pal_onoi: [],
                pal_stnoi: [],
            },
            Profit_before_Taxes: {
                pal_pbt: [],
            },
            Provision_for_taxation: {
                pal_pft: [],
            },
            Net_Profit: {
                pal_np: [],
            },
            Dividend_Withdrawals: {
                pal_dw: [],
            },
            Retained_profit: {
                pal_rp: [],
            },
        };
        let TableHeader = {
            date:[],
            heading:[]
        };
        for (var x = 1; x <= 6; x++) {
            // Sales_Revenue
            Profit_and_Loss.Sales_Revenue.pal_d.push({
                id: x,
                value: document.getElementById(`pal_d${x}`).value,
            });
            Profit_and_Loss.Sales_Revenue.pal_e.push({
                id: x,
                value: document.getElementById(`pal_e${x}`).value,
            });
            Profit_and_Loss.Sales_Revenue.pal_tns.push({
                id: x,
                value: document.getElementById(`pal_tns${x}`).value,
            });
            // Cost_of_Sales
            Profit_and_Loss.Cost_of_Sales.pal_rmsp.push({
                id: x,
                value: document.getElementById(`pal_rmsp${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_os.push({
                id: x,
                value: document.getElementById(`pal_os${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_pf.push({
                id: x,
                value: document.getElementById(`pal_pf${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_dlc.push({
                id: x,
                value: document.getElementById(`pal_dlc${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_rfag.push({
                id: x,
                value: document.getElementById(`pal_rfag${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_cosd.push({
                id: x,
                value: document.getElementById(`pal_cosd${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_ode.push({
                id: x,
                value: document.getElementById(`pal_ode${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_stcos.push({
                id: x,
                value: document.getElementById(`pal_stcos${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_aos.push({
                id: x,
                value: document.getElementById(`pal_aos${x}`).value,
            });
            Profit_and_Loss.Cost_of_Sales.pal_dcs.push({
                id: x,
                value: document.getElementById(`pal_dcs${x}`).value,
            });
            // Cost_of_Production
            Profit_and_Loss.Cost_of_Production.pal_stcop.push({
                id: x,
                value: document.getElementById(`pal_stcop${x}`).value,
            });
            // General_and_Admin_Expneses
            Profit_and_Loss.General_and_Admin_Expneses.pal_gaae.push({
                id: x,
                value: document.getElementById(`pal_gaae${x}`).value,
            });
            // Cost_of_SalesT
            Profit_and_Loss.Cost_of_SalesT.pal_cosT.push({
                id: x,
                value: document.getElementById(`pal_cosT${x}`).value,
            });
            // Operating_Profit
            Profit_and_Loss.Operating_Profit.pal_op.push({
                id: x,
                value: document.getElementById(`pal_op${x}`).value,
            });
            // Non_Operating_Expenses
            Profit_and_Loss.Non_Operating_Expenses.pal_inbb.push({
                id: x,
                value: document.getElementById(`pal_inbb${x}`).value,
            });
            Profit_and_Loss.Non_Operating_Expenses.pal_iolfo.push({
                id: x,
                value: document.getElementById(`pal_iolfo${x}`).value,
            });
            Profit_and_Loss.Non_Operating_Expenses.pal_onoe.push({
                id: x,
                value: document.getElementById(`pal_onoe${x}`).value,
            });
            Profit_and_Loss.Non_Operating_Expenses.pal_stnoe.push({
                id: x,
                value: document.getElementById(`pal_stnoe${x}`).value,
            });
            // Non_Operating_Income
            Profit_and_Loss.Non_Operating_Income.pal_ii.push({
                id: x,
                value: document.getElementById(`pal_ii${x}`).value,
            });
            Profit_and_Loss.Non_Operating_Income.pal_onoi.push({
                id: x,
                value: document.getElementById(`pal_onoi${x}`).value,
            });
            Profit_and_Loss.Non_Operating_Income.pal_stnoi.push({
                id: x,
                value: document.getElementById(`pal_stnoi${x}`).value,
            });
            // Profit_before_Taxes
            Profit_and_Loss.Profit_before_Taxes.pal_pbt.push({
                id: x,
                value: document.getElementById(`pal_pbt${x}`).value,
            });
            // Provision_for_taxation
            Profit_and_Loss.Provision_for_taxation.pal_pft.push({
                id: x,
                value: document.getElementById(`pal_pft${x}`).value,
            });
            // Net_Profit
            Profit_and_Loss.Net_Profit.pal_np.push({
                id: x,
                value: document.getElementById(`pal_np${x}`).value,
            });
            // Dividend_Withdrawals
            Profit_and_Loss.Dividend_Withdrawals.pal_dw.push({
                id: x,
                value: document.getElementById(`pal_dw${x}`).value,
            });
            // Retained_profit
            Profit_and_Loss.Retained_profit.pal_rp.push({
                id: x,
                value: document.getElementById(`pal_rp${x}`).value,
            });

            // TableHeader
            TableHeader.date.push({
                id: x,
                value: document.getElementById(`date${x}`).value
            })
            TableHeader.heading.push({
                id: x,
                value: document.getElementById(`head${x}`).value
            })
        }
        $.post(
            "save.php", {
                action: "PROFIT_AND_LOSS",
                data: JSON.stringify(Profit_and_Loss),
                ref: <?php echo $_GET['id']; ?>,
                TableHeader: JSON.stringify(TableHeader)
            },
            function(data, status) {
                console.log(data);
                window.location.href = "dscr_iscr.php?id=<?php echo $_GET['id']; ?>";
            }
        );
    };
    </script>
</body>

</html>