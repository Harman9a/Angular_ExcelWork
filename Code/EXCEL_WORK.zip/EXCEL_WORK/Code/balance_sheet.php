<?php include('config.php');
session_start();

if(!isset($_SESSION['id'])){
    header('location:login.php');
}

$res = mysqli_query($conn, "SELECT * FROM sheets WHERE ref_id=".$_GET['id']);
while ($row = mysqli_fetch_assoc($res)) {
    $_SESSION['company_name'] =  $row['company_name'];
}
 ?>
<!DOCTYPE html>

<html>

<head>
    <style>
        @page { margin: 0; }
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 5px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }

    .styled-table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }

    .heading {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-size: 0.9em;
        font-family: sans-serif;
        padding: 12px 15px;
    }
    .hInput{
        background-color: #029879;
        border: 1px solid white;
        color: white;
    }
    </style>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
</head>

<body>
    <div class="my-2">
        </div>
        <div class="row">
            <div class="col-sm-4">
                <h2>Balance Sheet</h2>
            </div>
            <div class="col-sm-7">
                <h2>Company Name: <?php echo $_SESSION['company_name']; ?></h2>
            </div>
            <div class="col-sm-1">
                <a href="logout.php"><b style="text-align:right">Logout</b></a>

            </div>
        </div>
        <div>
            <div style="float:right; margin-right:30px"><h6>Kyats in Mill.</h6></div>
        </div>
    <?php
$res = mysqli_query($conn, "SELECT * FROM balance_sheet WHERE ref_id=".$_GET['id']);
if($res->num_rows == 0 ){
    ?>
    <table class="styled-table">
        <thead>
            <tr>
            <th><h4>Liabilities</h4></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="date1" class='hInput' type="text" value="30.09.20" /></th>
                <th><input id="date2" class='hInput' type="text" value="30.09.21" /></th>
                <th><input id="date3" class='hInput' type="text" value="30.09.22" /></th>
                <th><input id="date4" class='hInput' type="text" value="30.09.23" /></th>
                <th><input id="date5" class='hInput' type="text" value="30.09.24" /></th>
                <th><input id="date6" class='hInput' type="text" value="30.09.25" /></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="head1" class='hInput' type="text" value="Audited" /></th>
                <th><input id="head2" class='hInput' type="text" value="Unaudited" /></th>
                <th><input id="head3" class='hInput' type="text" value="Estimated" /></th>
                <th><input id="head4" class='hInput' type="text" value="Projected" /></th>
                <th><input id="head5" class='hInput' type="text" value="Projected" /></th>
                <th><input id="head6" class='hInput' type="text" value="Projected" /></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>1) CURRENT LIABILITIES</th>
            </tr>
            <tr>
                <th>Short Term Borrowings from Banks.</th>
                <td>
                    <input type="text" name="bs_stbfb1" value="0" id="bs_stbfb1" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" name="bs_stbfb2" value="0" id="bs_stbfb2" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" name="bs_stbfb3" value="0" id="bs_stbfb3" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" name="bs_stbfb4" value="0" id="bs_stbfb4" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" name="bs_stbfb5" value="0" id="bs_stbfb5" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" name="bs_stbfb6" value="0" id="bs_stbfb6" onkeyup="sum_cl()" />
                </td>
            </tr>
            <tr>
                <th>Bank Loan Installments ( Due in Next 1 Yr. )</th>
                <td>
                    <input value="0" type="text" name="bs_bli1" id="bs_bli1" onkeyup="sum_cl()" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bli2" onkeyup="sum_cl()" name="bs_bli2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bli3" onkeyup="sum_cl()" name="bs_bli3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bli4" onkeyup="sum_cl()" name="bs_bli4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bli5" onkeyup="sum_cl()" name="bs_bli5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bli6" onkeyup="sum_cl()" name="bs_bli6" />
                </td>
            </tr>
            <tr>
                <th>Short Term Borrowings from Others.</th>
                <td>
                    <input type="text" value="0" id="bs_stbfo1" onkeyup="sum_cl()" name="bs_stbfo1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_stbfo2" onkeyup="sum_cl()" name="bs_stbfo2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_stbfo3" onkeyup="sum_cl()" name="bs_stbfo3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_stbfo4" onkeyup="sum_cl()" name="bs_stbfo4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_stbfo5" onkeyup="sum_cl()" name="bs_stbfo5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_stbfo6" onkeyup="sum_cl()" name="bs_stbfo6" />
                </td>
            </tr>
            <tr>
                <th>Trade Creditors</th>
                <td>
                    <input type="text" value="0" id="bs_tc1" onkeyup="sum_cl()" name="bs_tc1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tc2" onkeyup="sum_cl()" name="bs_tc2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tc3" onkeyup="sum_cl()" name="bs_tc3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tc4" onkeyup="sum_cl()" name="bs_tc4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tc5" onkeyup="sum_cl()" name="bs_tc5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tc6" onkeyup="sum_cl()" name="bs_tc6" />
                </td>
            </tr>
            <tr>
                <th>Advance Payments from Customers</th>
                <td>
                    <input type="text" value="0" id="bs_apfc1" onkeyup="sum_cl()" name="bs_apfc1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_apfc2" onkeyup="sum_cl()" name="bs_apfc2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_apfc3" onkeyup="sum_cl()" name="bs_apfc3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_apfc4" onkeyup="sum_cl()" name="bs_apfc4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_apfc5" onkeyup="sum_cl()" name="bs_apfc5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_apfc6" onkeyup="sum_cl()" name="bs_apfc6" />
                </td>
            </tr>
            <tr>
                <th>Taxes Payable.</th>
                <td>
                    <input type="text" value="0" id="bs_tp1" onkeyup="sum_cl()" name="bs_tp1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tp2" onkeyup="sum_cl()" name="bs_tp2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tp3" onkeyup="sum_cl()" name="bs_tp3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tp4" onkeyup="sum_cl()" name="bs_tp4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tp5" onkeyup="sum_cl()" name="bs_tp5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_tp6" onkeyup="sum_cl()" name="bs_tp6" />
                </td>
            </tr>
            <tr>
                <th>Accrued Expenses to be paid.</th>
                <td>
                    <input type="text" value="0" id="bs_aetbp1" onkeyup="sum_cl()" name="bs_aetbp1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_aetbp2" onkeyup="sum_cl()" name="bs_aetbp2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_aetbp3" onkeyup="sum_cl()" name="bs_aetbp3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_aetbp4" onkeyup="sum_cl()" name="bs_aetbp4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_aetbp5" onkeyup="sum_cl()" name="bs_aetbp5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_aetbp6" onkeyup="sum_cl()" name="bs_aetbp6" />
                </td>
            </tr>
            <tr>
                <th>Other Current Liabilities</th>
                <td>
                    <input type="text" value="0" id="bs_ocl1" onkeyup="sum_cl()" name="bs_ocl1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ocl2" onkeyup="sum_cl()" name="bs_ocl2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ocl3" onkeyup="sum_cl()" name="bs_ocl3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ocl4" onkeyup="sum_cl()" name="bs_ocl4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ocl5" onkeyup="sum_cl()" name="bs_ocl5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ocl6" onkeyup="sum_cl()" name="bs_ocl6" />
                </td>
            </tr>
            <tr>
                <th>TOTAL CURRENT LIABILITIES</th>
                <td>
                    <input type="text" name="bs_tcl1" value="0" id="bs_tcl1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcl2" value="0" id="bs_tcl2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcl3" value="0" id="bs_tcl3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcl4" value="0" id="bs_tcl4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcl5" value="0" id="bs_tcl5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcl6" value="0" id="bs_tcl6" disabled />
                </td>
            </tr>

            <!-- and so on... -->
            <tr>
                <th>2) MEDIUM & LONG TERM LIABILITIES</th>
            </tr>
            <tr>
                <th>Bank Term Loans (Outstanding)</th>
                <td>
                    <input type="text" name="bs_btlo1" value="0" id="bs_btlo1" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" name="bs_btlo2" value="0" id="bs_btlo2" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" name="bs_btlo3" value="0" id="bs_btlo3" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" name="bs_btlo4" value="0" id="bs_btlo4" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" name="bs_btlo5" value="0" id="bs_btlo5" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" name="bs_btlo6" value="0" id="bs_btlo6" onkeyup="sum_mltl()" />
                </td>
            </tr>
            <tr>
                <th>Loans from Directors.</th>
                <td>
                    <input value="0" type="text" name="bs_lfd1" id="bs_lfd1" onkeyup="sum_mltl()" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lfd2" onkeyup="sum_mltl()" name="bs_lfd2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lfd3" onkeyup="sum_mltl()" name="bs_lfd3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lfd4" onkeyup="sum_mltl()" name="bs_lfd4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lfd5" onkeyup="sum_mltl()" name="bs_lfd5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lfd6" onkeyup="sum_mltl()" name="bs_lfd6" />
                </td>
            </tr>
            <tr>
                <th>Loans from Friends and Relatives</th>
                <td>
                    <input type="text" value="0" id="bs_lffar1" onkeyup="sum_mltl()" name="bs_lffar1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lffar2" onkeyup="sum_mltl()" name="bs_lffar2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lffar3" onkeyup="sum_mltl()" name="bs_lffar3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lffar4" onkeyup="sum_mltl()" name="bs_lffar4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lffar5" onkeyup="sum_mltl()" name="bs_lffar5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lffar6" onkeyup="sum_mltl()" name="bs_lffar6" />
                </td>
            </tr>
            <tr>
                <th>Employee Benefits- Accumulated Funds</th>
                <td>
                    <input type="text" value="0" id="bs_ebaf1" onkeyup="sum_mltl()" name="bs_ebaf1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ebaf2" onkeyup="sum_mltl()" name="bs_ebaf2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ebaf3" onkeyup="sum_mltl()" name="bs_ebaf3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ebaf4" onkeyup="sum_mltl()" name="bs_ebaf4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ebaf5" onkeyup="sum_mltl()" name="bs_ebaf5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ebaf6" onkeyup="sum_mltl()" name="bs_ebaf6" />
                </td>
            </tr>
            <tr>
                <th>Other Medium & Long Term Liabilities</th>
                <td>
                    <input type="text" value="0" id="bs_omltl1" onkeyup="sum_mltl()" name="bs_omltl1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_omltl2" onkeyup="sum_mltl()" name="bs_omltl2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_omltl3" onkeyup="sum_mltl()" name="bs_omltl3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_omltl4" onkeyup="sum_mltl()" name="bs_omltl4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_omltl5" onkeyup="sum_mltl()" name="bs_omltl5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_omltl6" onkeyup="sum_mltl()" name="bs_omltl6" />
                </td>
            </tr>
            <tr>
                <th>TOTAL MED & LONG TERM LIABILITIES</th>
                <td>
                    <input type="text" name="bs_tmltl1" value="0" id="bs_tmltl1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tmltl2" value="0" id="bs_tmltl2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tmltl3" value="0" id="bs_tmltl3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tmltl4" value="0" id="bs_tmltl4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tmltl5" value="0" id="bs_tmltl5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tmltl6" value="0" id="bs_tmltl6" disabled />
                </td>
            </tr>

            <!-- and so on... -->

            <!-- and so on... -->
            <tr>
                <th>3) CAPITAL & RESERVE</th>
            </tr>

            <tr>
                <th>Share Capital</th>
                <td>
                    <input value="0" type="text" name="bs_sc1" id="bs_sc1" onkeyup="sum_cr()" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sc2" onkeyup="sum_cr()" name="bs_sc2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sc3" onkeyup="sum_cr()" name="bs_sc3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sc4" onkeyup="sum_cr()" name="bs_sc4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sc5" onkeyup="sum_cr()" name="bs_sc5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sc6" onkeyup="sum_cr()" name="bs_sc6" />
                </td>
            </tr>
            <tr>
                <th>General Reserves</th>
                <td>
                    <input type="text" value="0" id="bs_gr1" onkeyup="sum_cr()" name="bs_gr1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gr2" onkeyup="sum_cr()" name="bs_gr2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gr3" onkeyup="sum_cr()" name="bs_gr3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gr4" onkeyup="sum_cr()" name="bs_gr4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gr5" onkeyup="sum_cr()" name="bs_gr5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gr6" onkeyup="sum_cr()" name="bs_gr6" />
                </td>
            </tr>
            <tr>
                <th>Retained Earnings : Surplus / Deficit.</th>
                <td>
                    <input type="text" value="0" id="bs_resd1" onkeyup="sum_cr()" name="bs_resd1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_resd2" onkeyup="sum_cr()" name="bs_resd2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_resd3" onkeyup="sum_cr()" name="bs_resd3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_resd4" onkeyup="sum_cr()" name="bs_resd4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_resd5" onkeyup="sum_cr()" name="bs_resd5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_resd6" onkeyup="sum_cr()" name="bs_resd6" />
                </td>
            </tr>
            <tr>
                <th>Other</th>
                <td>
                    <input type="text" value="0" id="bs_o1" onkeyup="sum_cr()" name="bs_o1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_o2" onkeyup="sum_cr()" name="bs_o2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_o3" onkeyup="sum_cr()" name="bs_o3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_o4" onkeyup="sum_cr()" name="bs_o4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_o5" onkeyup="sum_cr()" name="bs_o5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_o6" onkeyup="sum_cr()" name="bs_o6" />
                </td>
            </tr>

            <tr>
                <th>TOTAL CAPITAL & RESERVES</th>
                <td>
                    <input type="text" name="bs_tcr1" value="0" id="bs_tcr1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcr2" value="0" id="bs_tcr2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcr3" value="0" id="bs_tcr3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcr4" value="0" id="bs_tcr4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcr5" value="0" id="bs_tcr5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tcr6" value="0" id="bs_tcr6" disabled />
                </td>
            </tr>
            <!-- and so on... -->
            <tr style="background-color: #009879">
                <th>TOTAL LIABILITIES</th>
                <td>
                    <input type="text" name="bs_tl1" value="0" id="bs_tl1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tl2" value="0" id="bs_tl2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tl3" value="0" id="bs_tl3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tl4" value="0" id="bs_tl4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tl5" value="0" id="bs_tl5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tl6" value="0" id="bs_tl6" disabled />
                </td>
            </tr>
        </tbody>
    </table>
    <table class="styled-table">
        <thead>
            <tr>
            <th style="position: absolute;"><h2>Assets</h2></th>
                <th>30.09.20</th>
                <th>30.09.21</th>
                <th>30.09.22</th>
                <th>30.09.23</th>
                <th>30.09.24</th>
                <th>30.09.25</th>
            </tr>
            <tr>
                <th></th>
                <th>Audited</th>
                <th>Unaudited</th>
                <th>Estimated</th>
                <th>Projected</th>
                <th>Projected</th>
                <th>Projected</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>4) CURRENT ASSETS</th>
            </tr>
            <tr>
                <th>Cash in hand</th>
                <td>
                    <input type="text" name="bs_cih1" value="0" id="bs_cih1" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" name="bs_cih2" value="0" id="bs_cih2" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" name="bs_cih3" value="0" id="bs_cih3" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" name="bs_cih4" value="0" id="bs_cih4" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" name="bs_cih5" value="0" id="bs_cih5" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" name="bs_cih6" value="0" id="bs_cih6" onkeyup="sum_ca()" />
                </td>
            </tr>

            ​
            <tr>
                <th>Bank Balances</th>
                <td>
                    <input value="0" type="text" name="bs_bb1" id="bs_bb1" onkeyup="sum_ca()" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bb2" onkeyup="sum_ca()" name="bs_bb2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bb3" onkeyup="sum_ca()" name="bs_bb3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bb4" onkeyup="sum_ca()" name="bs_bb4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bb5" onkeyup="sum_ca()" name="bs_bb5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_bb6" onkeyup="sum_ca()" name="bs_bb6" />
                </td>
            </tr>
            <tr>
                <th>Trade Debtors</th>
                <td>
                    <input type="text" value="0" id="bs_td1" onkeyup="sum_ca()" name="bs_td1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_td2" onkeyup="sum_ca()" name="bs_td2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_td3" onkeyup="sum_ca()" name="bs_td3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_td4" onkeyup="sum_ca()" name="bs_td4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_td5" onkeyup="sum_ca()" name="bs_td5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_td6" onkeyup="sum_ca()" name="bs_td6" />
                </td>
            </tr>
            <tr>
                <th>Short Term Investments</th>
                <td>
                    <input type="text" value="0" id="bs_sti1" onkeyup="sum_ca()" name="bs_sti1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sti2" onkeyup="sum_ca()" name="bs_sti2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sti3" onkeyup="sum_ca()" name="bs_sti3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sti4" onkeyup="sum_ca()" name="bs_sti4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sti5" onkeyup="sum_ca()" name="bs_sti5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_sti6" onkeyup="sum_ca()" name="bs_sti6" />
                </td>
            </tr>
            <tr>
                <th>Stocks / Inventory.</th>
                <td>
                    <input type="text" value="0" id="bs_si1" onkeyup="sum_ca()" name="bs_si1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_si2" onkeyup="sum_ca()" name="bs_si2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_si3" onkeyup="sum_ca()" name="bs_si3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_si4" onkeyup="sum_ca()" name="bs_si4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_si5" onkeyup="sum_ca()" name="bs_si5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_si6" onkeyup="sum_ca()" name="bs_si6" />
                </td>
            </tr>
            <tr>
                <th>Prepaid Expenses</th>
                <td>
                    <input type="text" value="0" id="bs_pe1" onkeyup="sum_ca()" name="bs_pe1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_pe2" onkeyup="sum_ca()" name="bs_pe2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_pe3" onkeyup="sum_ca()" name="bs_pe3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_pe4" onkeyup="sum_ca()" name="bs_pe4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_pe5" onkeyup="sum_ca()" name="bs_pe5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_pe6" onkeyup="sum_ca()" name="bs_pe6" />
                </td>
            </tr>
            <tr>
                <th>Advance to Suppliers</th>
                <td>
                    <input type="text" value="0" id="bs_ats1" onkeyup="sum_ca()" name="bs_ats1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ats2" onkeyup="sum_ca()" name="bs_ats2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ats3" onkeyup="sum_ca()" name="bs_ats3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ats4" onkeyup="sum_ca()" name="bs_ats4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ats5" onkeyup="sum_ca()" name="bs_ats5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ats6" onkeyup="sum_ca()" name="bs_ats6" />
                </td>
            </tr>
            <tr>
                <th>Other Current Assets</th>
                <td>
                    <input type="text" value="0" id="bs_oca1" onkeyup="sum_ca()" name="bs_oca1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oca2" onkeyup="sum_ca()" name="bs_oca2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oca3" onkeyup="sum_ca()" name="bs_oca3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oca4" onkeyup="sum_ca()" name="bs_oca4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oca5" onkeyup="sum_ca()" name="bs_oca5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oca6" onkeyup="sum_ca()" name="bs_oca6" />
                </td>
            </tr>
            <tr>
                <th>TOTAL CURRENT ASSETS</th>
                <td>
                    <input type="text" name="bs_tca1" value="0" id="bs_tca1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tca2" value="0" id="bs_tca2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tca3" value="0" id="bs_tca3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tca4" value="0" id="bs_tca4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tca5" value="0" id="bs_tca5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tca6" value="0" id="bs_tca6" disabled />
                </td>
            </tr>

            <!-- and so on... -->
            <tr>
                <th>5) FIXED ASSETS AND NON-CURRENT ASSETS</th>
            </tr>
            <tr>
                <th>Fixed Assets ( Net Block )</th>
                <td>
                    <input type="text" value="0" id="bs_fanb1" onkeyup="sum_fa()" name="bs_fanb1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_fanb2" onkeyup="sum_fa()" name="bs_fanb2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_fanb3" onkeyup="sum_fa()" name="bs_fanb3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_fanb4" onkeyup="sum_fa()" name="bs_fanb4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_fanb5" onkeyup="sum_fa()" name="bs_fanb5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_fanb6" onkeyup="sum_fa()" name="bs_fanb6" />
                </td>
            </tr>
            <tr>
                <th>Long Term Investments</th>
                <td>
                    <input type="text" value="0" id="bs_lti1" onkeyup="sum_fa()" name="bs_lti1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lti2" onkeyup="sum_fa()" name="lti2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lti3" onkeyup="sum_fa()" name="bs_lti3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lti4" onkeyup="sum_fa()" name="bs_lti4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lti5" onkeyup="sum_fa()" name="bs_lti5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_lti6" onkeyup="sum_fa()" name="bs_lti6" />
                </td>
            </tr>

            <tr>
                <th>Other Non-Current Assets</th>
                <td>
                    <input type="text" value="0" id="bs_onca1" onkeyup="sum_fa()" name="bs_onca1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_onca2" onkeyup="sum_fa()" name="onca2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_onca3" onkeyup="sum_fa()" name="bs_onca3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_onca4" onkeyup="sum_fa()" name="bs_onca4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_onca5" onkeyup="sum_fa()" name="bs_onca5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_onca6" onkeyup="sum_fa()" name="bs_onca6" />
                </td>
            </tr>
            <tr>
                <th>TOTAL FIXED ASSETS</th>
                <td>
                    <input type="text" name="bs_tfa1" value="0" id="bs_tfa1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tfa2" value="0" id="bs_tfa2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tfa3" value="0" id="bs_tfa3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tfa4" value="0" id="bs_tfa4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tfa5" value="0" id="bs_tfa5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tfa6" value="0" id="bs_tfa6" disabled />
                </td>
            </tr>

            <!-- and so on... -->
            <!-- and so on... -->
            <tr>
                <th>6) INTANGIBLE ASSETS</th>
            </tr>
            <tr>
                <th>Goodwill</th>
                <td>
                    <input type="text" value="0" id="bs_gw1" onkeyup="sum_ia()" name="bs_gw1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gw2" onkeyup="sum_ia()" name="bs_gw2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gw3" onkeyup="sum_ia()" name="bs_gw3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gw4" onkeyup="sum_ia()" name="bs_gw4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gw5" onkeyup="sum_ia()" name="bs_gw5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_gw6" onkeyup="sum_ia()" name="bs_gw6" />
                </td>
            </tr>
            <tr>
                <th>Preliminary Expenses.</th>
                <td>
                    <input type="text" value="0" id="bs_ple1" onkeyup="sum_ia()" name="bs_ple1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ple2" onkeyup="sum_ia()" name="ple2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ple3" onkeyup="sum_ia()" name="bs_ple3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ple4" onkeyup="sum_ia()" name="bs_ple4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ple5" onkeyup="sum_ia()" name="bs_ple5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_ple6" onkeyup="sum_ia()" name="bs_ple6" />
                </td>
            </tr>

            <tr>
                <th>Other Intangible Assets</th>
                <td>
                    <input type="text" value="0" id="bs_oia1" onkeyup="sum_ia()" name="bs_oia1" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oia2" onkeyup="sum_ia()" name="oia2" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oia3" onkeyup="sum_ia()" name="bs_oia3" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oia4" onkeyup="sum_ia()" name="bs_oia4" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oia5" onkeyup="sum_ia()" name="bs_oia5" />
                </td>
                <td>
                    <input type="text" value="0" id="bs_oia6" onkeyup="sum_ia()" name="bs_oia6" />
                </td>
            </tr>
            <tr>
                <th>TOTAL INTANGIBLE ASSETS</th>
                <td>
                    <input type="text" name="bs_tia1" value="0" id="bs_tia1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tia2" value="0" id="bs_tia2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tia3" value="0" id="bs_tia3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tia4" value="0" id="bs_tia4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tia5" value="0" id="bs_tia5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tia6" value="0" id="bs_tia6" disabled />
                </td>
            </tr>

            <!-- and so on... -->
            <tr style="background-color: #009879">
                <th>TOTAL ASSETS</th>
                <td>
                    <input type="text" name="bs_ta1" value="0" id="bs_ta1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_ta2" value="0" id="bs_ta2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_ta3" value="0" id="bs_ta3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_ta4" value="0" id="bs_ta4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_ta5" value="0" id="bs_ta5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_ta6" value="0" id="bs_ta6" disabled />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>Balancing (Total Assets - Total Liabilities)</th>
                <td>
                    <input type="text" name="bs_tb1" value="0" id="bs_tb1" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tb2" value="0" id="bs_tb2" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tb3" value="0" id="bs_tb3" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tb4" value="0" id="bs_tb4" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tb5" value="0" id="bs_tb5" disabled />
                </td>
                <td>
                    <input type="text" name="bs_tb6" value="0" id="bs_tb6" disabled />
                </td>
            </tr>
        </tbody>
    </table>
    <?php
}else{
while($row = mysqli_fetch_assoc($res)){
  $liabilities = json_decode($row['liabilities']);
  $assest = json_decode($row['assets']);
  $balancing = json_decode($row['balancing']);
  $TableHeader = json_decode($row['TableHeader']);
          ?>
    <table class="styled-table">
        <thead>

        <tr>
                <th><h4>Liabilities</h4></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="date1" class='hInput' type="text" value="<?php echo $TableHeader->date[0]->value ?>" /></th>
                <th><input id="date2" class='hInput' type="text" value="<?php echo $TableHeader->date[1]->value ?>" /></th>
                <th><input id="date3" class='hInput' type="text" value="<?php echo $TableHeader->date[2]->value ?>" /></th>
                <th><input id="date4" class='hInput' type="text" value="<?php echo $TableHeader->date[3]->value ?>" /></th>
                <th><input id="date5" class='hInput' type="text" value="<?php echo $TableHeader->date[4]->value ?>" /></th>
                <th><input id="date6" class='hInput' type="text" value="<?php echo $TableHeader->date[5]->value ?>" /></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="head1" class='hInput' type="text" value="<?php echo $TableHeader->heading[0]->value ?>" /></th>
                <th><input id="head2" class='hInput' type="text" value="<?php echo $TableHeader->heading[1]->value ?>" /></th>
                <th><input id="head3" class='hInput' type="text" value="<?php echo $TableHeader->heading[2]->value ?>" /></th>
                <th><input id="head4" class='hInput' type="text" value="<?php echo $TableHeader->heading[3]->value ?>" /></th>
                <th><input id="head5" class='hInput' type="text" value="<?php echo $TableHeader->heading[4]->value ?>" /></th>
                <th><input id="head6" class='hInput' type="text" value="<?php echo $TableHeader->heading[5]->value ?>" /></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>1 CURRENT LIABILITIES</th>
            </tr>
            <tr>
                <th>Short Term Borrowings from Banks.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_stbfb<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->stbfb[$i]->value; ?>"
                        id="bs_stbfb<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Bank Loan Installments ( Due in Next 1 Yr. )</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_bli<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_bli[$i]->value; ?>"
                        id="bs_bli<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Short Term Borrowings from Others.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_stbfo<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_stbfo[$i]->value; ?>"
                        id="bs_stbfo<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Trade Creditors</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tc<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_tc[$i]->value; ?>"
                        id="bs_tc<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Advance Payments from Customers</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_apfc<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_apfc[$i]->value; ?>"
                        id="bs_apfc<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Taxes Payable.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tp<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_tp[$i]->value; ?>"
                        id="bs_tp<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Accrued Expenses to be paid.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_aetbp<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_aetbp[$i]->value; ?>"
                        id="bs_aetbp<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Current Liabilities</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_ocl<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_ocl[$i]->value; ?>"
                        id="bs_ocl<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL CURRENT LIABILITIES</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tcl<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->CURRENT_LIABILITIES->bs_tcl[$i]->value; ?>"
                        id="bs_tcl<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>

            <!-- and so on... -->
            <tr>
                <th>2 MEDIUM & LONG TERM LIABILITIES</th>
            </tr>
            <tr>
                <th>Bank Term Loans (Outstanding)</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_btlo<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_btlo[$i]->value; ?>"
                        id="bs_btlo<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Loans from Directors.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_lfd<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_lfd[$i]->value; ?>"
                        id="bs_lfd<?php echo $i+1; ?>" onkeyup="sum_mltl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Loans from Friends and Relatives</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_lffar<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_lffar[$i]->value; ?>"
                        id="bs_lffar<?php echo $i+1; ?>" onkeyup="sum_mltl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Employee Benefits- Accumulated Funds</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_ebaf<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_ebaf[$i]->value; ?>"
                        id="bs_ebaf<?php echo $i+1; ?>" onkeyup="sum_mltl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Medium & Long Term Liabilities</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_omltl<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_omltl[$i]->value; ?>"
                        id="bs_omltl<?php echo $i+1; ?>" onkeyup="sum_mltl()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL MED & LONG TERM LIABILITIES</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tmltl<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->MEDIUM_AND_LONG_TERM_LIABILITIES->bs_tmltl[$i]->value; ?>"
                        id="bs_tmltl<?php echo $i+1; ?>" onkeyup="sum_cl()" />
                </td>
                <?php } ?>
            </tr>

            <!-- and so on... -->

            <!-- and so on... -->
            <tr>
                <th>3 CAPITAL & RESERVE</th>
            </tr>

            <tr>
                <th>Share Capital</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_sc<?php echo $i+1; ?>"
                        value="<?php echo $liabilities-> CAPITAL_AND_RESERVE->bs_sc[$i]->value; ?>"
                        id="bs_sc<?php echo $i+1; ?>" onkeyup="sum_cr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>General Reserves</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_gr<?php echo $i+1; ?>"
                        value="<?php echo $liabilities-> CAPITAL_AND_RESERVE->bs_gr[$i]->value; ?>"
                        id="bs_gr<?php echo $i+1; ?>" onkeyup="sum_cr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Retained Earnings : Surplus / Deficit.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_resd<?php echo $i+1; ?>"
                        value="<?php echo $liabilities-> CAPITAL_AND_RESERVE->bs_resd[$i]->value; ?>"
                        id="bs_resd<?php echo $i+1; ?>" onkeyup="sum_cr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_o<?php echo $i+1; ?>"
                        value="<?php echo $liabilities-> CAPITAL_AND_RESERVE->bs_o[$i]->value; ?>"
                        id="bs_o<?php echo $i+1; ?>" onkeyup="sum_cr()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL CAPITAL & RESERVES</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tcr<?php echo $i+1; ?>"
                        value="<?php echo $liabilities-> CAPITAL_AND_RESERVE->bs_tcr[$i]->value; ?>"
                        id="bs_tcr<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
            <!-- and so on... -->
            <tr style="background-color: #009879">
                <th>TOTAL LIABILITIES</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tl<?php echo $i+1; ?>"
                        value="<?php echo $liabilities->TOTAL_LIABILITIES[$i]->value; ?>"
                        id="bs_tl<?php echo $i+1; ?>"  />
                </td>
                <?php } ?>
            </tr>
        </tbody>
    </table>
    <table class="styled-table">
        <thead>
            <tr>
            <th style="position: absolute;"><h2>Assets</h2></th>
                <th>30.09.20</th>
                <th>30.09.21</th>
                <th>30.09.22</th>
                <th>30.09.23</th>
                <th>30.09.24</th>
                <th>30.09.25</th>
            </tr>
            <tr>
                <th></th>
                <th>Audited</th>
                <th>Unaudited</th>
                <th>Estimated</th>
                <th>Projected</th>
                <th>Projected</th>
                <th>Projected</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>4 CURRENT ASSETS</th>
            </tr>
            <tr>
                <th>Cash in hand</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_cih<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_cih[$i]->value; ?>" id="bs_cih<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Bank Balances</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_bb<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_bb[$i]->value; ?>" id="bs_bb<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Trade Debtors</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_td<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_td[$i]->value; ?>" id="bs_td<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Short Term Investments</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bbs_sti<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_sti[$i]->value; ?>" id="bs_sti<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Stocks / Inventory.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_si<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_si[$i]->value; ?>" id="bs_si<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Prepaid Expenses</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_pe<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_pe[$i]->value; ?>" id="bs_pe<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Advance to Suppliers</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_ats<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_ats[$i]->value; ?>" id="bs_ats<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Other Current Assets</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_oca<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_oca[$i]->value; ?>" id="bs_oca<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL CURRENT ASSETS</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tca<?php echo $i+1; ?>"
                        value="<?php echo $assest->CURRENT_ASSETS->bs_tca[$i]->value; ?>" id="bs_tca<?php echo $i+1; ?>"
                        onkeyup="sum_ca()" />
                </td>
                <?php } ?>
            </tr>

            <!-- and so on... -->
            <tr>
                <th>5 FIXED ASSETS AND NON-CURRENT ASSETS</th>
            </tr>
            <tr>
                <th>Fixed Assets ( Net Block )</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_fanb<?php echo $i+1; ?>"
                        value="<?php echo $assest->FIXED_ASSETS_AND_NON_CURRENT_ASSETS->bs_fanb[$i]->value; ?>"
                        id="bs_fanb<?php echo $i+1; ?>" onkeyup="sum_fa()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Long Term Investments</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_lti<?php echo $i+1; ?>"
                        value="<?php echo $assest->FIXED_ASSETS_AND_NON_CURRENT_ASSETS->bs_lti[$i]->value; ?>"
                        id="bs_lti<?php echo $i+1; ?>" onkeyup="sum_fa()" />
                </td>
                <?php } ?>
            </tr>

            <tr>
                <th>Other Non-Current Assets</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_onca<?php echo $i+1; ?>"
                        value="<?php echo $assest->FIXED_ASSETS_AND_NON_CURRENT_ASSETS->bs_onca[$i]->value; ?>"
                        id="bs_onca<?php echo $i+1; ?>" onkeyup="sum_fa()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL FIXED ASSETS</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tfa<?php echo $i+1; ?>"
                        value="<?php echo $assest->FIXED_ASSETS_AND_NON_CURRENT_ASSETS->bs_tfa[$i]->value; ?>"
                        id="bs_tfa<?php echo $i+1; ?>" onkeyup="sum_fa()" />
                </td>
                <?php } ?>
            </tr>

            <!-- and so on... -->
            <!-- and so on... -->
            <tr>
                <th>6 INTANGIBLE ASSETS</th>
            </tr>
            <tr>
                <th>Goodwill</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_gw<?php echo $i+1; ?>"
                        value="<?php echo $assest->INTANGIBLE_ASSETS->bs_gw[$i]->value; ?>"
                        id="bs_gw<?php echo $i+1; ?>" onkeyup="sum_ia()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>Preliminary Expenses.</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_ple<?php echo $i+1; ?>"
                        value="<?php echo $assest->INTANGIBLE_ASSETS->bs_ple[$i]->value; ?>"
                        id="bs_ple<?php echo $i+1; ?>" onkeyup="sum_ia()" />
                </td>
                <?php } ?>
            </tr>

            <tr>
                <th>Other Intangible Assets</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_oia<?php echo $i+1; ?>"
                        value="<?php echo $assest->INTANGIBLE_ASSETS->bs_oia[$i]->value; ?>"
                        id="bs_oia<?php echo $i+1; ?>" onkeyup="sum_ia()" />
                </td>
                <?php } ?>
            </tr>
            <tr>
                <th>TOTAL INTANGIBLE ASSETS</th>
                <?php 
              for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tia<?php echo $i+1; ?>"
                        value="<?php echo $assest->INTANGIBLE_ASSETS->bs_tia[$i]->value; ?>"
                        id="bs_tia<?php echo $i+1; ?>" onkeyup="sum_ia()" />
                </td>
                <?php } ?>
            </tr>

            <!-- and so on... -->
            <tr style="background-color: #009879">
                <th>TOTAL ASSETS</th>
                <?php 
               for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_ta<?php echo $i+1; ?>"
                        value="<?php echo $assest->TOTAL_ASSETS[$i]->value; ?>" id="bs_ta<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
            <tr style="background-color: #009879">
                <th>Balancing (Total Assets - Total Liabilities)</th>
                <?php 
               for($i = 0 ; $i<=5 ; $i++){
            ?>
                <td>
                    <input type="text" name="bs_tb<?php echo $i+1; ?>" value="<?php echo $balancing[$i]->value; ?>"
                        id="bs_tb<?php echo $i+1; ?>" />
                </td>
                <?php } ?>
            </tr>
        </tbody>
    </table>
    <?php 
   }
}
  ?>
    <div class="my-2" id="bnts">
        <button class="btn btn-success" onclick="saveAll()">Next (Profit & Loss)</button>
        <button class="btn btn-success" onclick="PrintAll()">Print</button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
    PrintAll = () => {
        document.getElementById('bnts').style.display = 'none';
        window.print();
        document.getElementById('bnts').style.display = 'block';
    }
    function sum_cl() {
        for (var x = 1; x <= 6; x++) {
            var bs_stbfb = parseFloat(
                document.getElementById(`bs_stbfb${x}`).value
            );
            var bs_bli = parseFloat(document.getElementById(`bs_bli${x}`).value);
            var bs_stbfo = parseFloat(
                document.getElementById(`bs_stbfo${x}`).value
            );
            var bs_tc = parseFloat(document.getElementById(`bs_tc${x}`).value);
            var bs_apfc = parseFloat(document.getElementById(`bs_apfc${x}`).value);
            var bs_tp = parseFloat(document.getElementById(`bs_tp${x}`).value);
            var bs_aetbp = parseFloat(
                document.getElementById(`bs_aetbp${x}`).value
            );
            var bs_ocl = parseFloat(document.getElementById(`bs_ocl${x}`).value);

            let total = bs_stbfb + bs_bli + bs_stbfo + bs_tc + bs_apfc + bs_tp + bs_aetbp + bs_ocl;

            document.getElementById(`bs_tcl${x}`).value = total.toFixed(2);
        }
        sum_total_laibility();
    }

    function sum_mltl() {
        for (var x = 1; x <= 6; x++) {
            var bs_btlo = parseFloat(document.getElementById(`bs_btlo${x}`).value);
            var bs_lfd = parseFloat(document.getElementById(`bs_lfd${x}`).value);
            console.log('ok');
            var bs_lffar = parseFloat(
                document.getElementById(`bs_lffar${x}`).value
            );
            var bs_ebaf = parseFloat(document.getElementById(`bs_ebaf${x}`).value);
            var bs_omltl = parseFloat(
                document.getElementById(`bs_omltl${x}`).value
            );

            let total = bs_btlo + bs_lfd + bs_lffar + bs_ebaf + bs_omltl;
            document.getElementById(`bs_tmltl${x}`).value = total.toFixed(2);
        }
        sum_total_laibility();
    }

    function sum_cr() {
        for (var x = 1; x <= 6; x++) {
            var bs_sc = parseFloat(document.getElementById(`bs_sc${x}`).value);
            var bs_gr = parseFloat(document.getElementById(`bs_gr${x}`).value);
            var bs_resd = parseFloat(document.getElementById(`bs_resd${x}`).value);
            var bs_o = parseFloat(document.getElementById(`bs_o${x}`).value);

            let total = bs_sc + bs_gr + bs_resd + bs_o;
            document.getElementById(`bs_tcr${x}`).value = total.toFixed(2);
        }
        sum_total_laibility();
    }

    function sum_total_laibility() {
        for (var x = 1; x <= 6; x++) {
            var sum_cl = parseFloat(document.getElementById(`bs_tcl${x}`).value);
            var sum_mltl = parseFloat(
                document.getElementById(`bs_tmltl${x}`).value
            );
            var sum_cr = parseFloat(document.getElementById(`bs_tcr${x}`).value);
            let total = sum_cl + sum_mltl + sum_cr;
            document.getElementById(`bs_tl${x}`).value = total.toFixed(2);
        }
        sum_total_balancing();
    }

    function sum_ca() {
        for (var x = 1; x <= 6; x++) {
            var bs_cih = parseFloat(document.getElementById(`bs_cih${x}`).value);
            var bs_bb = parseFloat(document.getElementById(`bs_bb${x}`).value);
            var bs_td = parseFloat(document.getElementById(`bs_td${x}`).value);
            var bs_sti = parseFloat(document.getElementById(`bs_sti${x}`).value);
            var bs_si = parseFloat(document.getElementById(`bs_si${x}`).value);
            var bs_pe = parseFloat(document.getElementById(`bs_pe${x}`).value);
            var bs_ats = parseFloat(document.getElementById(`bs_ats${x}`).value);
            var bs_oca = parseFloat(document.getElementById(`bs_oca${x}`).value);
            let total = bs_cih + bs_bb + bs_td + bs_sti + bs_si + bs_pe + bs_ats + bs_oca;
            document.getElementById(`bs_tca${x}`).value = total.toFixed(2);

        }
        sum_total_assets();
    }

    function sum_fa() {
        for (var x = 1; x <= 6; x++) {
            var bs_fanb = parseFloat(document.getElementById(`bs_fanb${x}`).value);
            var bs_lti = parseFloat(document.getElementById(`bs_lti${x}`).value);
            var bs_onca = parseFloat(document.getElementById(`bs_onca${x}`).value);

            let total  =  bs_fanb + bs_lti + bs_onca;
            document.getElementById(`bs_tfa${x}`).value = total.toFixed(2);
        }
        sum_total_assets();
    }

    function sum_ia() {
        for (var x = 1; x <= 6; x++) {
            var bs_gw = parseFloat(document.getElementById(`bs_gw${x}`).value);
            var bs_ple = parseFloat(document.getElementById(`bs_ple${x}`).value);
            var bs_oia = parseFloat(document.getElementById(`bs_oia${x}`).value);

            let total = bs_gw + bs_ple + bs_oia;
            document.getElementById(`bs_tia${x}`).value = total.toFixed(2);
        }
        sum_total_assets();
    }

    function sum_total_assets() {
        for (var x = 1; x <= 6; x++) {
            var sum_ca = parseFloat(document.getElementById(`bs_tca${x}`).value);
            var sum_fa = parseFloat(document.getElementById(`bs_tfa${x}`).value);
            var sum_ia = parseFloat(document.getElementById(`bs_tia${x}`).value);
            let total = sum_ca + sum_fa + sum_ia;
            document.getElementById(`bs_ta${x}`).value = total.toFixed(2);
        }
        sum_total_balancing();
    }

    function sum_total_balancing() {
        for (var x = 1; x <= 6; x++) {
            var sum_total_assets = parseFloat(
                document.getElementById(`bs_ta${x}`).value
            );
            var sum_total_laibility = parseFloat(
                document.getElementById(`bs_tl${x}`).value
            );

            let total = sum_total_assets - sum_total_laibility
            document.getElementById(`bs_tb${x}`).value = total.toFixed(2);
        }
    }
    saveAll = () => {
        let Liabilities = {
            CURRENT_LIABILITIES: {
                stbfb: [],
                bs_bli: [],
                bs_stbfo: [],
                bs_tc: [],
                bs_apfc: [],
                bs_tp: [],
                bs_aetbp: [],
                bs_ocl: [],
                bs_tcl: [],
            },
            MEDIUM_AND_LONG_TERM_LIABILITIES: {
                bs_btlo: [],
                bs_lfd: [],
                bs_lffar: [],
                bs_ebaf: [],
                bs_omltl: [],
                bs_tmltl: [],
            },
            CAPITAL_AND_RESERVE: {
                bs_sc: [],
                bs_gr: [],
                bs_resd: [],
                bs_o: [],
                bs_tcr: [],
            },
            TOTAL_LIABILITIES: [],
        };
        let Assets = {
            CURRENT_ASSETS: {
                bs_cih: [],
                bs_bb: [],
                bs_td: [],
                bs_sti: [],
                bs_si: [],
                bs_pe: [],
                bs_ats: [],
                bs_oca: [],
                bs_tca: [],
            },
            FIXED_ASSETS_AND_NON_CURRENT_ASSETS: {
                bs_fanb: [],
                bs_lti: [],
                bs_onca: [],
                bs_tfa: [],
            },
            INTANGIBLE_ASSETS: {
                bs_gw: [],
                bs_ple: [],
                bs_oia: [],
                bs_tia: [],
            },
            TOTAL_ASSETS: [],
        };
        let Balancing = [];

        let TableHeader = {
            date:[],
            heading:[]
        };

        for (var x = 1; x <= 6; x++) {
            // CURRENT_LIABILITIES
            Liabilities.CURRENT_LIABILITIES.stbfb.push({
                id: x,
                value: document.getElementById(`bs_stbfb${x}`).value,
            });

            Liabilities.CURRENT_LIABILITIES.bs_bli.push({
                id: x,
                value: document.getElementById(`bs_bli${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_stbfo.push({
                id: x,
                value: document.getElementById(`bs_stbfo${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_tc.push({
                id: x,
                value: document.getElementById(`bs_tc${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_apfc.push({
                id: x,
                value: document.getElementById(`bs_apfc${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_tp.push({
                id: x,
                value: document.getElementById(`bs_tp${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_aetbp.push({
                id: x,
                value: document.getElementById(`bs_aetbp${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_ocl.push({
                id: x,
                value: document.getElementById(`bs_ocl${x}`).value,
            });
            Liabilities.CURRENT_LIABILITIES.bs_tcl.push({
                id: x,
                value: document.getElementById(`bs_tcl${x}`).value,
            });
            // MEDIUM_AND_LONG_TERM_LIABILITIES
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_btlo.push({
                id: x,
                value: document.getElementById(`bs_btlo${x}`).value,
            });
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_lfd.push({
                id: x,
                value: document.getElementById(`bs_lfd${x}`).value,
            });
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_lffar.push({
                id: x,
                value: document.getElementById(`bs_lffar${x}`).value,
            });
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_ebaf.push({
                id: x,
                value: document.getElementById(`bs_ebaf${x}`).value,
            });
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_omltl.push({
                id: x,
                value: document.getElementById(`bs_omltl${x}`).value,
            });
            Liabilities.MEDIUM_AND_LONG_TERM_LIABILITIES.bs_tmltl.push({
                id: x,
                value: document.getElementById(`bs_tmltl${x}`).value,
            });
            // CAPITAL_AND_RESERVE
            Liabilities.CAPITAL_AND_RESERVE.bs_sc.push({
                id: x,
                value: document.getElementById(`bs_sc${x}`).value,
            });
            Liabilities.CAPITAL_AND_RESERVE.bs_gr.push({
                id: x,
                value: document.getElementById(`bs_gr${x}`).value,
            });
            Liabilities.CAPITAL_AND_RESERVE.bs_resd.push({
                id: x,
                value: document.getElementById(`bs_resd${x}`).value,
            });
            Liabilities.CAPITAL_AND_RESERVE.bs_o.push({
                id: x,
                value: document.getElementById(`bs_o${x}`).value,
            });
            Liabilities.CAPITAL_AND_RESERVE.bs_tcr.push({
                id: x,
                value: document.getElementById(`bs_tcr${x}`).value,
            });
            // TOTAL_LIABILITIES
            Liabilities.TOTAL_LIABILITIES.push({
                id: x,
                value: document.getElementById(`bs_tl${x}`).value,
            });
            // Assets
            // CURRENT_ASSETS
            Assets.CURRENT_ASSETS.bs_cih.push({
                id: x,
                value: document.getElementById(`bs_cih${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_bb.push({
                id: x,
                value: document.getElementById(`bs_bb${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_td.push({
                id: x,
                value: document.getElementById(`bs_td${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_sti.push({
                id: x,
                value: document.getElementById(`bs_sti${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_si.push({
                id: x,
                value: document.getElementById(`bs_si${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_pe.push({
                id: x,
                value: document.getElementById(`bs_pe${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_ats.push({
                id: x,
                value: document.getElementById(`bs_ats${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_oca.push({
                id: x,
                value: document.getElementById(`bs_oca${x}`).value,
            });
            Assets.CURRENT_ASSETS.bs_tca.push({
                id: x,
                value: document.getElementById(`bs_tca${x}`).value,
            });
            // FIXED_ASSETS_AND_NON_CURRENT_ASSETS
            Assets.FIXED_ASSETS_AND_NON_CURRENT_ASSETS.bs_fanb.push({
                id: x,
                value: document.getElementById(`bs_fanb${x}`).value,
            });
            Assets.FIXED_ASSETS_AND_NON_CURRENT_ASSETS.bs_lti.push({
                id: x,
                value: document.getElementById(`bs_lti${x}`).value,
            });
            Assets.FIXED_ASSETS_AND_NON_CURRENT_ASSETS.bs_onca.push({
                id: x,
                value: document.getElementById(`bs_onca${x}`).value,
            });
            Assets.FIXED_ASSETS_AND_NON_CURRENT_ASSETS.bs_tfa.push({
                id: x,
                value: document.getElementById(`bs_tfa${x}`).value,
            });
            // INTANGIBLE_ASSETS
            Assets.INTANGIBLE_ASSETS.bs_gw.push({
                id: x,
                value: document.getElementById(`bs_gw${x}`).value,
            });
            Assets.INTANGIBLE_ASSETS.bs_ple.push({
                id: x,
                value: document.getElementById(`bs_ple${x}`).value,
            });
            Assets.INTANGIBLE_ASSETS.bs_oia.push({
                id: x,
                value: document.getElementById(`bs_oia${x}`).value,
            });
            Assets.INTANGIBLE_ASSETS.bs_tia.push({
                id: x,
                value: document.getElementById(`bs_tia${x}`).value,
            });
            // TOTAL_ASSETS
            Assets.TOTAL_ASSETS.push({
                id: x,
                value: document.getElementById(`bs_ta${x}`).value,
            });
            // Balancing
            Balancing.push({
                id: x,
                value: document.getElementById(`bs_tb${x}`).value,
            });

            // TableHeader
            TableHeader.date.push({
                id: x,
                value: document.getElementById(`date${x}`).value
            })
            TableHeader.heading.push({
                id: x,
                value: document.getElementById(`head${x}`).value
            })
        }

        $.post(
            "save.php", {
                action: "BALANCE_SHEET",
                Liabilities: JSON.stringify(Liabilities),
                Assets: JSON.stringify(Assets),
                Balancing: JSON.stringify(Balancing),
                TableHeader: JSON.stringify(TableHeader),
                ref: <?php echo $_GET['id']; ?>
            },
            function(data, status) {
                console.log(data);
                window.location.href = "profitloss.php?id=<?php echo $_GET['id']; ?>"
            }
        );
    };
    </script>
</body>

</html>