
<html>
<head>
<title>Table 03</title>
<meta charset="utf-8" />
<meta
  name="viewport"
  content="width=device-width, initial-scale=1, shrink-to-fit=no"
/>
<link
  href="https://fonts.googleapis.com/css?family=Roboto:400,100,300,700"
  rel="stylesheet"
  type="text/css"
/>
<link
  rel="stylesheet"
  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
/>
<link rel="stylesheet" href="https://preview.colorlib.com/theme/bootstrap/table-03/css/A.style.css.pagespeed.cf.PlwJDa5bmm.css" />
<style>
.table thead th {
    border: none;
    padding: 20px 30px;
    font-size: 14px;
    color: #fff;
}
.table thead.thead-primary {
    background: #655480d6;
}
</style>
</head>
<body>
<section >
  <div>
    <div class="row justify-content-center">
      <div class="col-md-6 text-center mb-3">
        <h2 class="heading-section">Key Financials and Ratios</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <h4 class="text-center mb-4">Company Name: demo</h4>
        <div class="table-wrap">
          <table class="table">
            <thead class="thead-primary">
              <tr>
                <th></th>
                <th>30.09.20</th>
                <th>30.09.21</th>
                <th>30.09.22</th>
                <th>30.09.23</th>
                <th>30.09.24</th>
                <th>30.09.25</th>
              </tr>
              <tr>
                <th></th>
                <th>Audited</th>
                <th>Unaudited</th>
                <th>Estimated</th>
                <th>Projected</th>
                <th>Projected</th>
                <th>Projected</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row" class="scope" style="width:15%">Share Capital (Equity)</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Net Worth</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Net Block</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Net Sales</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Increase in Sales <br /> ( % age )</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Net Profit</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Depreciation</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Cash Accruals	</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Profitability Ratio  PAT/Net Sales</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Return On Capital Employed (ROCE)</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Current Assets</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Current Liabilities</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Current Ratio	</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Debt/Equity Ratio </th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Debt Service Coverage Ratio (DSCR)</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">DSCR ( Average )</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Interest Service Coverage Ratio (ISCR)</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">ISCR ( Average )</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <th scope="row" class="scope">Debt Collection Period (Days)</th>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://preview.colorlib.com/theme/bootstrap/table-03/js/jquery.min.js"></script>
<script src="https://preview.colorlib.com/theme/bootstrap/table-03/js/popper.js+bootstrap.min.js+main.js.pagespeed.jc.mGo61WuhWO.js"></script>
<script
  defer
  src="https://static.cloudflareinsights.com/beacon.min.js"
></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js" ></script>
</body>
</html>