<?php include('config.php'); ?>
<?php
session_start();

if(!isset($_SESSION['id'])){
    header('location:login.php');
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $des = $_POST['des'];
    $rand = rand();
    $user_id = $_SESSION["id"];
    $res = mysqli_query($conn, "INSERT into sheets (company_name,description,ref_id,user_id) VALUES ('" . $name . "','" . $des . "','" . $rand . "','".$user_id."')");
    header('location:balance_sheet.php?id=' . $rand);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
</head>

<body>
    <div class="container">
        <div class="jumbotron">
            <h1>All Sheets</h1>
        </div>
        <div class="row">
            <div class="col-sm-11">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    New Sheet
                </button>

            </div>
            <div class="col-sm-1">
                <a href="logout.php"><b style="text-align:right">Logout</b></a>

            </div>
        </div>
        <div class="row js-slick-carousel my-5">
            <?php
            $res = mysqli_query($conn, "SELECT * FROM sheets WHERE user_id=".$_SESSION["id"]);
            while ($row = mysqli_fetch_assoc($res)) {
            ?>
            <div class="col-4 my-2">
                <div class="card" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['company_name']; ?></h5>
                        <p class="card-text">
                            <?php echo $row['description']; ?>
                        </p>
                        <a href="balance_sheet.php?id=<?php echo $row['ref_id']; ?>" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <!-- row -->
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="text" class="form-control" name="name" id="name" placeholder="Name" /><br />
                        <input type="text" class="form-control" name="des" id="des" placeholder="Description" />
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="submit" class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js">
    </script>
</body>

</html>