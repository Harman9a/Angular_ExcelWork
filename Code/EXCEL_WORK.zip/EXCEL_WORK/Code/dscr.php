<?php include('config.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <style>
      .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
      }
      .styled-table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
      }
      .styled-table th,
      .styled-table td {
        padding: 12px 15px;
      }
      .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
      }

      .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
      }

      .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
      }
      .styled-table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
      }
      .heading {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-size: 0.9em;
        font-family: sans-serif;
        padding: 12px 15px;
      }
    </style>
  </head>

  <body>


    <h2>Dscr - Iscr</h2>

<?php
$res = mysqli_query($conn, "SELECT * FROM profit_loss");
while($row = mysqli_fetch_assoc($res)){
  $data = json_decode($row['data']);
?>  ​
    <table class="styled-table">
      <thead>
        <tr>
          <th>Calculation of Debt Service Coverage Ratio</th>
        </tr>
        <tr>
          <th></th>
          <th>Year</th>
          <th>Year</th>
          <th>Year</th>
          <th>Year</th>

          <th></th>
        </tr>
        <tr>
          <th></th>
          <th>Sep,2022</th>
          <th>Sep,2023</th>
          <th>Sep,2024</th>
          <th>Sep,2025</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th></th>
        </tr>
        <tr>
          <th>Profit After Taxes</th>
          <td>
            <?php
            
            foreach($data->Net_Profit->pal_np as $row2){
              if($row2->id == 3){
            ?>
                <input
                  type="text"
                  name="dscr_pat1"
                  value="<?php echo $row2->value; ?>"
                  id="dscr_pat1"
                  onkeyup="dscr_cif()"
                /><?php
              }
            }
            ?>
          </td>
          <td>
            <input
              type="text"
              name="dscr_pat2"
              value="0"
              id="dscr_pat2"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_pat3"
              value="0"
              id="dscr_pat3"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_pat4"
              value="0"
              id="dscr_pat4"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_pat5"
              value="0"
              id="dscr_pat5"
              onkeyup="dscr_cif()"
            />
          </td>
        </tr>
        <tr>
          <th>Depreciation</th>
          <td>
            <input
              type="text"
              name="dscr_d1"
              value="0"
              id="dscr_d1"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_d2"
              value="0"
              id="dscr_d2"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_d3"
              value="0"
              id="dscr_d3"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_d4"
              value="0"
              id="dscr_d4"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_d5"
              value="0"
              id="dscr_d5"
              onkeyup="dscr_cif()"
            />
          </td>
        </tr>
        <tr>
          <th>Interest</th>
          <td>
            <input
              type="text"
              name="dscr_i1"
              value="0"
              id="dscr_i1"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_i2"
              value="0"
              id="dscr_i2"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_i3"
              value="0"
              id="dscr_i3"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_i4"
              value="0"
              id="dscr_i4"
              onkeyup="dscr_cif()"
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_i5"
              value="0"
              id="dscr_i5"
              onkeyup="dscr_cif()"
            />
          </td>
        </tr>
        <tr style="background-color: #009879">
          <th>A. Cash Inflows</th>
          <td>
            <input
              type="text"
              name="dscr_cif1"
              value="0"
              id="dscr_cif1"
              disabled
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_cif2"
              value="0"
              id="dscr_cif2"
              disabled
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_cif3"
              value="0"
              id="dscr_cif3"
              disabled
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_cif4"
              value="0"
              id="dscr_cif4"
              disabled
            />
          </td>
          <td>
            <input
              type="text"
              name="dscr_cif5"
              value="0"
              id="dscr_cif5"
              disabled
            />
          </td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr>
          <th>Instalments Payable.</th>
          <td>
            <input
              type="text"
              name="pal_d1"
              value="0"
              id="pal_d1"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d2"
              value="0"
              id="pal_d2"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d3"
              value="0"
              id="pal_d3"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d4"
              value="0"
              id="pal_d4"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d5"
              value="0"
              id="pal_d5"
              onkeyup="sum_sr()"
            />
          </td>
        </tr>
        <tr>
          <th>Interest Payable</th>
          <td>
            <input
              type="text"
              name="pal_d1"
              value="0"
              id="pal_d1"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d2"
              value="0"
              id="pal_d2"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d3"
              value="0"
              id="pal_d3"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d4"
              value="0"
              id="pal_d4"
              onkeyup="sum_sr()"
            />
          </td>
          <td>
            <input
              type="text"
              name="pal_d5"
              value="0"
              id="pal_d5"
              onkeyup="sum_sr()"
            />
          </td>
        </tr>
        <tr style="background-color: #009879">
          <th>B. Cash Outflows</th>
          <td>
            <input type="text" name="pal_rp1" value="0" id="pal_rp1" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp2" value="0" id="pal_rp2" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp3" value="0" id="pal_rp3" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp4" value="0" id="pal_rp4" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp5" value="0" id="pal_rp5" disabled />
          </td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr style="background-color: cornflowerblue">
          <th>DSCR</th>
          <td>
            <input type="text" name="pal_rp1" value="0" id="pal_rp1" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp2" value="0" id="pal_rp2" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp3" value="0" id="pal_rp3" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp4" value="0" id="pal_rp4" disabled />
          </td>
          <td>
            <input type="text" name="pal_rp5" value="0" id="pal_rp5" disabled />
          </td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr style="background-color: cornflowerblue">
          <th>Average DSCR</th>
          <td>
            <input type="text" name="pal_rp5" value="0" id="pal_rp5" disabled />
          </td>
        </tr>
      </tbody>
    </table>
    <?php
    }
    ?>
  </body>
</html>
