<?php
//error_reporting(0);

header('Access-Control-Allow-Origin: *');
$DB_host = "localhost";
    $DB_user = "root";
    $DB_pass = "wordpress";
   

    $DB_name = "excel_work";
    $conn = mysqli_connect($DB_host , $DB_user , $DB_pass ,$DB_name );

    
if($_POST['action_id'] == '1')
{

    
    $check = mysqli_query($conn, "SELECT * FROM test WHERE c_id=".$_POST['c_id']); 

    if($check->num_rows != 0){
      $u_res =  mysqli_query($conn, "UPDATE test SET data='".$_POST['a1']."'   WHERE c_id='".$_POST['c_id']."'");
        if($u_res){
            echo 1;
        }
    }else{
        $sql = " INSERT INTO test(id,data,c_id) VALUES ('".$_POST['id']."','".$_POST['a1']."','".$_POST['c_id']."')";
        $result = mysqli_query($conn, $sql);
           if($result){
               echo 1;
           }
           }
   
}

if($_POST['action_id'] == '2')
{
    $csql = "INSERT INTO Companies(user_name,company_name,facility, year) VALUES ('".$_POST['name']."','".$_POST['cname']."','".$_POST['type']."','".$_POST['Year']."')";
        $cresult = mysqli_query($conn, $csql);
           if($cresult){
               echo 1;
           } 

}

if($_POST['action_id'] == '3')
{
    $res = mysqli_query($conn, "SELECT * FROM Companies");
    while ($row = mysqli_fetch_assoc($res)) {
        $response[] = $row;
    
    }
    echo json_encode($response);


}


if($_POST['action_id'] == '4')
{

    
    $check_pf = mysqli_query($conn, "SELECT * FROM profitloss WHERE c_id=".$_POST['c_id']); 

    if($check_pf->num_rows != 0){
      $u_res_pf =  mysqli_query($conn, "UPDATE profitloss SET data='".$_POST['a1']."'   WHERE c_id='".$_POST['c_id']."'");
        if($u_res_pf){
            echo 1;
        }
    }else{
        $sql_pf = " INSERT INTO profitloss(id,data,c_id) VALUES ('".$_POST['id']."','".$_POST['a1']."','".$_POST['c_id']."')";
        $result_pf = mysqli_query($conn, $sql_pf);
           if($result_pf){
               echo 1;
           }
           }
   
}

if($_POST['action_id'] == '5')
{

    
    $check_id = mysqli_query($conn, "SELECT * FROM ds_is WHERE c_id=".$_POST['c_id']); 

    if($check_id->num_rows != 0){
      $u_res_di =  mysqli_query($conn, "UPDATE ds_is SET dscr='".$_POST['ds']."'   WHERE c_id='".$_POST['c_id']."'");
        if($u_res_di){
            echo 1;
        }
    }else{
        $sql_di = " INSERT INTO ds_is(dscr,c_id) VALUES ('".$_POST['ds']."','".$_POST['c_id']."')";
        $result_di = mysqli_query($conn, $sql_di);
           if($result_di){
               echo 1;
           }
           }
   
}

if($_POST['action_id'] == '6')
{

    
    $check_is = mysqli_query($conn, "SELECT * FROM iscr WHERE c_id=".$_POST['c_id']); 

    if($check_is->num_rows != 0){
      $u_res_is =  mysqli_query($conn, "UPDATE iscr SET iscr='".$_POST['is']."'   WHERE c_id='".$_POST['c_id']."'");
        if($u_res_is){
            echo 1;
        }
    }else{
        $sql_is = " INSERT INTO iscr(iscr,c_id) VALUES ('".$_POST['is']."','".$_POST['c_id']."')";
        $result_is = mysqli_query($conn, $sql_is);
           if($result_is){
               echo 1;
           }
           }
   
}

?>