
<?php 
  
 require('fpdf.php'); 
$conn = mysqli_connect("localhost", "Teamwebcodice", "Amritsar1!", "Teamliveprojects");
// $conn = mysqli_connect("localhost", "root", "", "Teamliveprojects");
$sql = "SELECT * FROM employee_payslip where id='".$_GET['rid']."'";  
$result = mysqli_query($conn, $sql);  
while($row = mysqli_fetch_array($result))  
{       
// New object created and constructor invoked 
$pdf = new FPDF(); 
  
// Add new pages. By default no pages available. 
$pdf->AddPage(); 
  
// Set font format and font-size
$pdf->SetFont('Times', 'B', 20); 
  
// Framed rectangular area 
// $pdf->Cell(176, 5, '', 0, 0, 'C'); 
  
  
  
 
// Set it new line 
$pdf->Ln(); 
  
// Set font format and font-size 
$pdf->SetFont('Times', '', 10); 
  

// $pdf->Image('Mug.jpg',10,20,33,0,'C','http://www.fpdf.org/');

// $image1 = "newpdf.jpg";
// $pdf->Image($image1,10, $pdf->GetY(), 185.150);
// Framed rectangular area 
// $pdf->Cell(185, 70, 'Date:-'.$row["dates"].' ', 0, 0, 'L'); 
// $pdf->Cell(250, 10, 'Print Date:-'.$row["printingdate"].'', 0, 0, 'R'); 
//  $pdf->Cell(50, 25, 'Invoice No:-' .$row["invoiceno"].'', 0, 0, 'L'); 
//  $pdf->Cell(250, 25, 'Invoice Name:-' .$row["invoicename"].'', 0, 0, 'R');
 

$pdf->Cell(71 ,5,'',0,0);
$pdf->Cell(59 ,5,'',0,0);
$pdf->Cell(59 ,5,'',0,1);

$pdf->SetLeftMargin(20);
// $pdf->SetTopMargin(90);
$pdf->Cell(60 ,60,'Employee Name:- '.$row["employee_name"].'',0,0);
$pdf->Cell(90 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,1);
// $pdf->Cell(90 ,65,'Name:- '.$row["invoicename"].'',0,0);
// $pdf->Cell(34 ,55,''.$row["invoicename"].'',0,1);

// $pdf->Cell(90 ,5,'',0,0);
// $pdf->Cell(30 ,5,'',0,0);
// $pdf->Cell(30 ,5,'',0,1);
$pdf->Cell(30 ,5,'',0,1);

// $pdf->Cell(90 ,60,'Employee Hourly Rate:-'.$row["printingdate"].'',0,0);
$pdf->Cell(10 ,55,'Employee Hourly Rate:-'.$row["employee_hourly_rate"].'',0,0);
$pdf->Cell(90 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,1);
$pdf->Cell(20 ,60,'Monthly Salary:-'.$row["monthly_salary"].'',0,0);
$pdf->Cell(90 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,1);
$pdf->Cell(30 ,65,'Month:-'.$row["select_month"].'',0,0);
$pdf->Cell(90 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,1);
$pdf->Cell(20 ,70,'Employee Monthly Total Hour:-'.$row["employee_monthly_total_hour"].'',0,0);
$pdf->Cell(90 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,0);
$pdf->Cell(30 ,5,'',0,1);
$pdf->Cell(10 ,75,'Total Monthly Salary:-'.$row["increment_hourly_salary"].'',0,0);
// $pdf->Cell(40 ,5,''.$row["invoiceno"].'',0,1);
// $pdf->Cell(290 ,250,'Print Date:-'.$row["printingdate"].'',0,0);
$pdf->Ln(20);
$pdf -> SetY(76); 
// $pdf->Cell(40,200,'Mantova,li '.$row["printingdate"].'',0,0);
// $pdf->Cell(130 ,5,'',0,0);
// $pdf->Cell(25 ,5,'Invoice No:-',0,0);
// $pdf->Cell(34 ,5,''.$row["invoiceno"].'',0,1);
// $pdf->Cell( 100,80, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 20.20), 0, 0, 'C', false );
}
// Close document and sent to the browser 
$pdf->Output(); 
  
?> 
