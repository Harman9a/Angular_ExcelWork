<?php
include 'header_1.php';
    session_start();
    $message="";
    if(count($_POST)>0) {
        $con = mysqli_connect('localhost','root','wordpress','excel_work') or die('Unable To connect');
        $result = mysqli_query($con,"SELECT * FROM user WHERE name='" . $_POST["name"] . "' and password = '". md5($_POST["password"])."'");
        $row  = mysqli_fetch_array($result);
        if(is_array($row)) {
        $_SESSION["id"] = $row['id'];
        $_SESSION["name"] = $row['name'];
        } else {
         $message = "Invalid Username or Password!";
        }
    }
    if(isset($_SESSION["id"])) {
    header("Location:index.php");
    }
?>
<html>

<head>
    <title>User Login</title>
    <style>
        .btn{
            font-size: 17px;
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 5px 10px;
    color: #fff;
    background-color: #333;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s;
        }
        #wrapper {
  width: 1000px;
  margin: 50px auto 0;
  background-color: #fff;
  height: 350px;
}

    </style>
</head>

<body>
    <form name="frmUser" method="post" action="" align="center">
        <div class="message"><?php if($message!="") { echo $message; } ?></div>
        <h3 align="center">Enter Login Details</h3>
        Username:<br>
        <input type="text" style="padding: 5px; width: 200px;" onfocus="this.value" name=" name">
        <br>
        Password:<br>
        <input type="password" style="padding: 5px; width: 200px;" onfocus="this.value=" name="password">
        <br><br>
        <input type="submit" name="submit" value="Login" class="btn">
        <br>
        <br>
        <h3>If You Don't have an account ?</h3>
        <a style="text-decoration:none ; margin-bottom:5px;" href="register.php">
            <h3>Register here</h3>
        </a>
    </form>

    <script>
    function validation() {
        var clear = document.
    }
    </script>
</body>

</html>