<?php include('config.php');

session_start();

if(!isset($_SESSION['id'])){
    header('location:login.php');
}
?>
<!DOCTYPE html>

<html>

<head>
    <style>
        @page { margin: 0; }
    .styled-table {
        border-collapse: collapse;
        margin: 25px 0;
        font-size: 0.9em;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .styled-table thead tr {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
    }

    .styled-table th,
    .styled-table td {
        padding: 12px 5px;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f3f3f3;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #009879;
    }

    .styled-table tbody tr.active-row {
        font-weight: bold;
        color: #009879;
    }

    .heading {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-size: 0.9em;
        font-family: sans-serif;
        padding: 12px 15px;
    }
    .hInput{
        background-color: #029879;
        border: 1px solid white;
        color: white;
    }
    </style>
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
</head>

<body>
    ​

    <div class="row">
        <div class="col-sm-4">
                <h2>DSCR - ISCR</h2>
            </div>
            <div class="col-sm-7">
                <h2>Company Name: <?php echo $_SESSION['company_name']; ?></h2>
            </div>
            <div class="col-sm-1">
                <a href="logout.php"><b style="text-align:right">Logout</b></a>

            </div>
        </div>
        <div>
            <div style="float:right; margin-right:30px"><h6>Kyats in Mill.</h6></div>
        </div>
    <?php
$res = mysqli_query($conn, "SELECT * FROM profit_loss WHERE ref_id=".$_GET['id']);
while($row = mysqli_fetch_assoc($res)){
  $data = json_decode($row['data']);
  $TableHeader = json_decode($row['TableHeader']);
?>
    ​
    <table class="styled-table">
        <thead>
            <tr>
                <th>Calculation of Debt Service Coverage Ratio</th>
            </tr>
            <tr>
                <th></th>
                <th>Year</th>
                <th>Year</th>
                <th>Year</th>
                <th>Year</th>

                <th></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="Ddate1" class="hInput" value="<?php echo $TableHeader->date[2]->value; ?>" /></th>
                <th><input id="Ddate2" class="hInput" value="<?php echo $TableHeader->date[3]->value; ?>" /></th>
                <th><input id="Ddate3" class="hInput" value="<?php echo $TableHeader->date[4]->value; ?>" /></th>
                <th><input id="Ddate4" class="hInput" value="<?php echo $TableHeader->date[5]->value; ?>" /></th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th></th>
            </tr>
            <tr>
                <th>Profit After Taxes</th>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 3){ ?>
                    <input type="text" name="dscr_pat1" value="<?php echo $row2->value; ?>" id="dscr_pat1"
                        onkeyup="dscr_cif()" disabled /><?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 4){ ?>
                    <input type="text" name="dscr_pat2" value="<?php echo $row2->value; ?>" id="dscr_pat2"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 5){ ?>
                    <input type="text" name="dscr_pat3" value="<?php echo $row2->value; ?>" id="dscr_pat3"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 6){ ?>
                    <input type="text" name="dscr_pat4" value="<?php echo $row2->value; ?>" id="dscr_pat4"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="dscr_pat5" value="0" id="dscr_pat5" onkeyup="dscr_cif()" disabled />
                </td>
            </tr>
            <tr>
                <th>Depreciation</th>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            3){ ?>
                    <input type="text" name="dscr_d1" value="<?php echo $row2->value; ?>" id="dscr_d1"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            4){ ?>
                    <input type="text" name="dscr_d2" value="<?php echo $row2->value; ?>" id="dscr_d2"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            5){ ?>
                    <input type="text" name="dscr_d3" value="<?php echo $row2->value; ?>" id="dscr_d3"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            6){ ?>
                    <input type="text" name="dscr_d4" value="<?php echo $row2->value; ?>" id="dscr_d4"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="dscr_d5" value="0" id="dscr_d5" onkeyup="dscr_cif()" disabled />
                </td>
            </tr>
            <tr>
                <th>Interest</th>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 3){ ?>
                    <input type="text" name="dscr_i1" value="<?php echo $row2->value; ?>" id="dscr_i1"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 4){ ?>
                    <input type="text" name="dscr_i2" value="<?php echo $row2->value; ?>" id="dscr_i2"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 5){ ?>
                    <input type="text" name="dscr_i3" value="<?php echo $row2->value; ?>" id="dscr_i3"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 6){ ?>
                    <input type="text" name="dscr_i4" value="<?php echo $row2->value; ?>" id="dscr_i4"
                        onkeyup="dscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="dscr_i5" value="0" id="dscr_i5" onkeyup="dscr_cif()" disabled />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>A. Cash Inflows</th>
                <td>
                    <input type="text" name="dscr_cif1" value="0" id="dscr_cif1" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cif2" value="0" id="dscr_cif2" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cif3" value="0" id="dscr_cif3" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cif4" value="0" id="dscr_cif4" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cif5" value="0" id="dscr_cif5" disabled />
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>

            <?php
$res2 = mysqli_query($conn, "SELECT * FROM balance_sheet  WHERE ref_id=".$_GET['id']);
while($row3 = mysqli_fetch_assoc($res2)){
  $data2 = json_decode($row3['liabilities']);
?>
            ​
            <tr>
                <th>Instalments Payable.</th>
                <td>
                    <?php
            foreach($data2->CURRENT_LIABILITIES->bs_bli as $row4){ if($row4->id
            == 3){ ?>
                    <input type="text" name="dscr_ip1" value="<?php echo $row4->value; ?>" id="dscr_ip1"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data2->CURRENT_LIABILITIES->bs_bli as $row4){ if($row4->id
            == 4){ ?>
                    <input type="text" name="dscr_ip2" value="<?php echo $row4->value; ?>" id="dscr_ip2"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data2->CURRENT_LIABILITIES->bs_bli as $row4){ if($row4->id
            == 5){ ?>
                    <input type="text" name="dscr_ip3" value="<?php echo $row4->value; ?>" id="dscr_ip3"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data2->CURRENT_LIABILITIES->bs_bli as $row4){ if($row4->id
            == 6){ ?>
                    <input type="text" name="dscr_ip4" value="<?php echo $row4->value; ?>" id="dscr_ip4"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="dscr_ip5" value="0" id="dscr_ip5" onkeyup="dscr_cof()" disabled />
                </td>
            </tr>

            <?php
            break;
}
        ?>
            <tr>
                <th>Interest Payable</th>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 3){ ?>
                    <input type="text" name="dscr_intp1" value="<?php echo $row2->value; ?>" id="dscr_intp1"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 4){ ?>
                    <input type="text" name="dscr_intp2" value="<?php echo $row2->value; ?>" id="dscr_intp2"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 5){ ?>
                    <input type="text" name="dscr_intp3" value="<?php echo $row2->value; ?>" id="dscr_intp3"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 6){ ?>
                    <input type="text" name="dscr_intp4" value="<?php echo $row2->value; ?>" id="dscr_intp4"
                        onkeyup="dscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="dscr_intp5" value="0" id="dscr_intp5" onkeyup="dscr_cof()" disabled />
                </td>
            </tr>

            <tr style="background-color: #009879">
                <th>B. Cash Outflows</th>
                <td>
                    <input type="text" name="dscr_cof1" value="0" id="dscr_cof1" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cof2" value="0" id="dscr_cof2" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cof3" value="0" id="dscr_cof3" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cof4" value="0" id="dscr_cof4" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_cof5" value="0" id="dscr_cof5" disabled />
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr style="background-color: cornflowerblue">
                <th>DSCR</th>
                <td>
                    <input type="text" name="dscr_dscr1" value="0" id="dscr_dscr1" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_dscr2" value="0" id="dscr_dscr2" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_dscr3" value="0" id="dscr_dscr3" disabled />
                </td>
                <td>
                    <input type="text" name="dscr_dscr4" value="0" id="dscr_dscr4" disabled />
                </td>
                <td>
                    <!-- <input type="text" name="dscr_dscr5" value="0" id="dscr_dscr5" disabled /> -->
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr style="background-color: cornflowerblue">
                <th>Average DSCR</th>
                <td>
                    <input type="text" name="dscr_avgdscr" value="0" id="dscr_avgdscr" disabled />
                </td>
            </tr>
        </tbody>
    </table>

    <table class="styled-table">
        <thead>
            <tr>
                <th>Calculation of Interest Service Coverage Ratio</th>
            </tr>
            <tr>
                <th></th>
                <th>Year</th>
                <th>Year</th>
                <th>Year</th>
                <th>Year</th>

                <th></th>
            </tr>
            <tr>
                <th></th>
                <th><input id="Idate1" class="hInput" value="<?php echo $TableHeader->date[2]->value; ?>" /></th>
                <th><input id="Idate2" class="hInput" value="<?php echo $TableHeader->date[3]->value; ?>" /></th>
                <th><input id="Idate3" class="hInput" value="<?php echo $TableHeader->date[4]->value; ?>" /></th>
                <th><input id="Idate4" class="hInput" value="<?php echo $TableHeader->date[5]->value; ?>" /></th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th></th>
            </tr>
            <tr>
                <th>Profit After Taxes</th>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 3){ ?>
                    <input type="text" name="iscr_pat1" value="<?php echo $row2->value; ?>" id="iscr_pat1"
                        onkeyup="iscr_cif()" disabled /><?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 4){ ?>
                    <input type="text" name="iscr_pat2" value="<?php echo $row2->value; ?>" id="iscr_pat2"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 5){ ?>
                    <input type="text" name="iscr_pat3" value="<?php echo $row2->value; ?>" id="iscr_pat3"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Net_Profit->pal_np as $row2){ if($row2->id == 6){ ?>
                    <input type="text" name="iscr_pat4" value="<?php echo $row2->value; ?>" id="iscr_pat4"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="iscr_pat5" value="0" id="iscr_pat5" onkeyup="iscr_cif()" disabled />
                </td>
            </tr>
            <tr>
                <th>Depreciation</th>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            3){ ?>
                    <input type="text" name="iscr_d1" value="<?php echo $row2->value; ?>" id="iscr_d1"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            4){ ?>
                    <input type="text" name="iscr_d2" value="<?php echo $row2->value; ?>" id="iscr_d2"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            5){ ?>
                    <input type="text" name="iscr_d3" value="<?php echo $row2->value; ?>" id="iscr_d3"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Cost_of_Sales->pal_cosd as $row2){ if($row2->id ==
            6){ ?>
                    <input type="text" name="iscr_d4" value="<?php echo $row2->value; ?>" id="iscr_d4"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="iscr_d5" value="0" id="iscr_d5" onkeyup="iscr_cif()" disabled />
                </td>
            </tr>
            <tr>
                <th>Interest</th>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 3){ ?>
                    <input type="text" name="iscr_i1" value="<?php echo $row2->value; ?>" id="iscr_i1"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 4){ ?>
                    <input type="text" name="iscr_i2" value="<?php echo $row2->value; ?>" id="iscr_i2"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 5){ ?>
                    <input type="text" name="iscr_i3" value="<?php echo $row2->value; ?>" id="iscr_i3"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 6){ ?>
                    <input type="text" name="iscr_i4" value="<?php echo $row2->value; ?>" id="iscr_i4"
                        onkeyup="iscr_cif()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <input type="text" name="iscr_i5" value="0" id="iscr_i5" onkeyup="iscr_cif()" disabled />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>A. Cash Inflows</th>
                <td>
                    <input type="text" name="iscr_cif1" value="0" id="iscr_cif1" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cif2" value="0" id="iscr_cif2" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cif3" value="0" id="iscr_cif3" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cif4" value="0" id="iscr_cif4" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cif5" value="0" id="iscr_cif5" disabled />
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr></tr>

            <tr>
                <th>Interest Payable</th>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 3){ ?>
                    <input type="text" name="iscr_intp1" value="<?php echo $row2->value; ?>" id="iscr_intp1"
                        onkeyup="iscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 4){ ?>
                    <input type="text" name="iscr_intp2" value="<?php echo $row2->value; ?>" id="iscr_intp2"
                        onkeyup="iscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 5){ ?>
                    <input type="text" name="iscr_intp3" value="<?php echo $row2->value; ?>" id="iscr_intp3"
                        onkeyup="iscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>
                <td>
                    <?php
            
            foreach($data->Non_Operating_Expenses->pal_stnoe as $row2){
            if($row2->id == 6){ ?>
                    <input type="text" name="iscr_intp4" value="<?php echo $row2->value; ?>" id="iscr_intp4"
                        onkeyup="iscr_cof()" disabled />
                    <?php
              }
            }
            ?>
                </td>

                <td>
                    <input type="text" name="iscr_intp5" value="0" id="iscr_intp5" onkeyup="iscr_cof()" disabled />
                </td>
            </tr>
            <tr style="background-color: #009879">
                <th>B. Cash Outflows</th>
                <td>
                    <input type="text" name="iscr_cof1" value="0" id="iscr_cof1" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cof2" value="0" id="iscr_cof2" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cof3" value="0" id="iscr_cof3" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cof4" value="0" id="iscr_cof4" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_cof5" value="0" id="iscr_cof5" disabled />
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr style="background-color: cornflowerblue">
                <th>ISCR</th>
                <td>
                    <input type="text" name="iscr_iscr1" value="0" id="iscr_iscr1" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_iscr2" value="0" id="iscr_iscr2" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_iscr3" value="0" id="iscr_iscr3" disabled />
                </td>
                <td>
                    <input type="text" name="iscr_iscr4" value="0" id="iscr_iscr4" disabled />
                </td>
                <td>
                    <!-- <input type="text" name="dscr_dscr5" value="0" id="dscr_dscr5" disabled /> -->
                </td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr style="background-color: cornflowerblue">
                <th>Average ISCR</th>
                <td>
                    <input type="text" name="iscr_avgiscr" value="0" id="iscr_avgiscr" disabled />
                </td>
            </tr>
        </tbody>
    </table>
    <?php
    }
    ?>
    <div class="my-2" id="bnts">
        <button class="btn btn-success" onclick="saveAll()">Next (Key Financials and Ratios)</button>
        <button class="btn btn-success" onclick="PrintAll()">Print</button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
    PrintAll = () => {
        document.getElementById('bnts').style.display = 'none';
        window.print();
        document.getElementById('bnts').style.display = 'block';
    }
    saveAll = () => {
        let Debt_Service = {
            Profit_After_Taxes: {
                dscr_pat: [],
            },
            Depreciation: {
                dscr_d: [],
            },
            Interest: {
                dscr_i: [],
            },
            Cash_Inflows: {
                dscr_cif: [],
            },
            Instalments_Payable: {
                dscr_ip: [],
            },
            Interest_Payable: {
                dscr_intp: [],
            },
            Cash_Outflows: {
                dscr_cof: [],
            },
            DSCR: {
                dscr_dscr: [],
            },
            Average_DSCR: {
                dscr_avgdscr: [],
            },
        };
        let Interest_Service = {
            Profit_After_Taxes: {
                iscr_pat: [],
            },
            Depreciation: {
                iscr_d: [],
            },
            Interest: {
                iscr_i: [],
            },
            Cash_Inflows: {
                iscr_cif: [],
            },
            Interest_Payable: {
                iscr_intp: [],
            },
            Cash_Outflows: {
                iscr_cof: [],
            },
            iscr: {
                iscr_iscr: [],
            },
            Average_ISCR: {
                iscr_avgiscr: [],
            },
        };

        let TableHeader = {
            Ddate: [],
            Idate: []
        }

        for (var x = 1; x <= 5; x++) {
            // Debt_Service
            Debt_Service.Profit_After_Taxes.dscr_pat.push({
                id: x,
                value: document.getElementById(`dscr_pat${x}`).value,
            });
            Debt_Service.Depreciation.dscr_d.push({
                id: x,
                value: document.getElementById(`dscr_d${x}`).value,
            });
            Debt_Service.Interest.dscr_i.push({
                id: x,
                value: document.getElementById(`dscr_i${x}`).value,
            });
            Debt_Service.Cash_Inflows.dscr_cif.push({
                id: x,
                value: document.getElementById(`dscr_cif${x}`).value,
            });
            Debt_Service.Instalments_Payable.dscr_ip.push({
                id: x,
                value: document.getElementById(`dscr_ip${x}`).value,
            });
            Debt_Service.Interest_Payable.dscr_intp.push({
                id: x,
                value: document.getElementById(`dscr_intp${x}`).value,
            });
            Debt_Service.Cash_Outflows.dscr_cof.push({
                id: x,
                value: document.getElementById(`dscr_cof${x}`).value,
            });
            if (x < 5) {
                Debt_Service.DSCR.dscr_dscr.push({
                    id: x,
                    value: document.getElementById(`dscr_dscr${x}`).value,
                });
            }
        }
        Debt_Service.Average_DSCR.dscr_avgdscr.push({
            id: "x",
            value: document.getElementById(`dscr_avgdscr`).value,
        });
        for (var x = 1; x <= 5; x++) {
            // Debt_Service
            Interest_Service.Profit_After_Taxes.iscr_pat.push({
                id: x,
                value: document.getElementById(`iscr_pat${x}`).value,
            });
            Interest_Service.Depreciation.iscr_d.push({
                id: x,
                value: document.getElementById(`iscr_d${x}`).value,
            });
            Interest_Service.Interest.iscr_i.push({
                id: x,
                value: document.getElementById(`iscr_i${x}`).value,
            });
            Interest_Service.Cash_Inflows.iscr_cif.push({
                id: x,
                value: document.getElementById(`iscr_cif${x}`).value,
            });
            Interest_Service.Interest_Payable.iscr_intp.push({
                id: x,
                value: document.getElementById(`iscr_intp${x}`).value,
            });
            Interest_Service.Cash_Outflows.iscr_cof.push({
                id: x,
                value: document.getElementById(`iscr_cof${x}`).value,
            });
            if (x < 5) {
                Interest_Service.iscr.iscr_iscr.push({
                    id: x,
                    value: document.getElementById(`iscr_iscr${x}`).value,
                });
            }
            if(x<5){
                TableHeader.Ddate.push({
                    id: x,
                    value: document.getElementById(`Ddate${x}`).value,
                });
                TableHeader.Idate.push({
                    id: x,
                    value: document.getElementById(`Idate${x}`).value,
                });
            }
        }
        Interest_Service.Average_ISCR.iscr_avgiscr.push({
            id: "x",
            value: document.getElementById(`iscr_avgiscr`).value,
        });
        $.post(
            "save.php", {
                action: "DSCR_AND_ISCR",
                dscr: JSON.stringify(Debt_Service),
                iscr: JSON.stringify(Interest_Service),
                TableHeader: JSON.stringify(TableHeader),
                ref: <?php echo $_GET['id']; ?>
            },
            function(data, status) {
                console.log(data);
                window.location.href = "key_Financials_and_Ratios.php?id=<?php echo $_GET['id']; ?>"
            }
        );
    };

    function dscr_cif() {
        var four_total = 0;
        var four_total1 = 0;
        var four_total2 = 0;
        for (var x = 1; x <= 4; x++) {
            four_total += parseFloat(
                document.getElementById(`dscr_pat${x}`).value
            );
            four_total1 += parseFloat(
                document.getElementById(`dscr_d${x}`).value
            );
            four_total2 += parseFloat(
                document.getElementById(`dscr_i${x}`).value
            );
        }
        document.getElementById(`dscr_pat5`).value = four_total.toFixed(2);
        document.getElementById(`dscr_d5`).value = four_total1.toFixed(2);
        document.getElementById(`dscr_i5`).value = four_total2.toFixed(2);

        for (var x = 1; x <= 5; x++) {
            var dscr_pat = parseFloat(
                document.getElementById(`dscr_pat${x}`).value
            );
            var dscr_d = parseFloat(document.getElementById(`dscr_d${x}`).value);
            var dscr_i = parseFloat(document.getElementById(`dscr_i${x}`).value);

            let total  = dscr_pat + dscr_d + dscr_i;
            document.getElementById(`dscr_cif${x}`).value = total.toFixed(2);

        }

        // console.log(four_total);
    }
    dscr_cif();

    function dscr_cof() {
        var four_total3 = 0;
        var four_total4 = 0;

        for (var x = 1; x <= 4; x++) {
            four_total3 += parseFloat(
                document.getElementById(`dscr_ip${x}`).value
            );
            four_total4 += parseFloat(
                document.getElementById(`dscr_intp${x}`).value
            );
        }
        document.getElementById(`dscr_ip5`).value = four_total3.toFixed(2);
        document.getElementById(`dscr_intp5`).value = four_total4.toFixed(2);

        for (var x = 1; x <= 5; x++) {
            var dscr_ip = parseFloat(
                document.getElementById(`dscr_ip${x}`).value
            );
            var dscr_intp = parseFloat(
                document.getElementById(`dscr_intp${x}`).value
            );

            let total = dscr_ip + dscr_intp;
            document.getElementById(`dscr_cof${x}`).value = total.toFixed(2);
        }

        // console.log(four_total);
    }
    dscr_cof();

    function dscr_dscr() {
        for (var x = 1; x <= 4; x++) {
            var dscr_cif = parseFloat(
                document.getElementById(`dscr_cif${x}`).value
            );

            var dscr_cof = parseFloat(
                document.getElementById(`dscr_cof${x}`).value
            );

            let total = dscr_cif / dscr_cof;
            document.getElementById(`dscr_dscr${x}`).value = total.toFixed(2);
        }
    }
    dscr_dscr();

    function dscr_avgdscr() {
        var dscr_cif5 = parseFloat(document.getElementById(`dscr_cif5`).value);

        var dscr_cof5 = parseFloat(document.getElementById(`dscr_cof5`).value);

        let total = dscr_cif5 / dscr_cof5;
        document.getElementById(`dscr_avgdscr`).value = total.toFixed(2);
    }

    dscr_avgdscr();
    </script>

    <script type="text/javascript">
    function iscr_cif() {
        var four_total = 0;
        var four_total1 = 0;
        var four_total2 = 0;
        for (var x = 1; x <= 4; x++) {
            four_total += parseFloat(
                document.getElementById(`iscr_pat${x}`).value
            );
            four_total1 += parseFloat(
                document.getElementById(`iscr_d${x}`).value
            );
            four_total2 += parseFloat(
                document.getElementById(`iscr_i${x}`).value
            );
        }
        document.getElementById(`iscr_pat5`).value = four_total.toFixed(2);
        document.getElementById(`iscr_d5`).value = four_total1.toFixed(2);
        document.getElementById(`iscr_i5`).value = four_total2.toFixed(2);

        for (var x = 1; x <= 5; x++) {
            var iscr_pat = parseFloat(
                document.getElementById(`iscr_pat${x}`).value
            );
            var iscr_d = parseFloat(document.getElementById(`iscr_d${x}`).value);
            var iscr_i = parseFloat(document.getElementById(`iscr_i${x}`).value);

            let total = iscr_pat + iscr_d + iscr_i;
            document.getElementById(`iscr_cif${x}`).value = total.toFixed(2);
        }

        // console.log(four_total);
    }
    iscr_cif();

    function iscr_cof() {
        var four_total3 = 0;
        var four_total4 = 0;

        for (var x = 1; x <= 4; x++) {
            // four_total3 += parseFloat(document.getElementById(`iscr_ip${x}`).value);
            four_total4 += parseFloat(
                document.getElementById(`iscr_intp${x}`).value
            );
        }
        // document.getElementById(`iscr_ip5`).value= four_total3;
        document.getElementById(`iscr_intp5`).value = four_total4.toFixed(2);

        for (var x = 1; x <= 5; x++) {
            // var iscr_ip = parseFloat(document.getElementById(`iscr_ip${x}`).value);
            var iscr_intp = parseFloat(
                document.getElementById(`iscr_intp${x}`).value
            );

            document.getElementById(`iscr_cof${x}`).value = iscr_intp.toFixed(2);
        }

        // console.log(four_total);
    }
    iscr_cof();

    function iscr_iscr() {
        for (var x = 1; x <= 4; x++) {
            var iscr_cif = parseFloat(
                document.getElementById(`iscr_cif${x}`).value
            );

            var iscr_cof = parseFloat(
                document.getElementById(`iscr_cof${x}`).value
            );

            let total = iscr_cif / iscr_cof;
            document.getElementById(`iscr_iscr${x}`).value = total.toFixed(2);
        }
    }
    iscr_iscr();

    function iscr_avgiscr() {
        var iscr_cif5 = parseFloat(document.getElementById(`iscr_cif5`).value);

        var iscr_cof5 = parseFloat(document.getElementById(`iscr_cof5`).value);

        let total = iscr_cif5 / iscr_cof5
        document.getElementById(`iscr_avgiscr`).value = total.toFixed(2);
    }
    iscr_avgiscr();
    </script>
</body>

</html>