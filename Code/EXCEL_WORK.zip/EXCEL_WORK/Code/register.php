<?php
session_start();

?>

<?php include 'header_2.php';
include 'config.php';
if(isset($_POST["submitbtn"]))
{
    $stu_name = $_POST['name'];
  $stu_email = $_POST['email'];
  $stu_password = md5($_POST['password']);
 $sql = " INSERT INTO user(name,email,password) VALUES ('{$stu_name}', '{$stu_email}', '{$stu_password}')";
 $result = mysqli_query($conn, $sql) or die("query unsuccessfull.");
 header("Location:login.php");
 mysqli_close($conn);
}

?>
<div id="main-content">
    <h2 style="text-align:center">Register Here</h2>
    <form class="post-form" onsubmit="return validation()" action="" method="post">
        <div class="form-group">
            <label>Name</label>
            <input style="padding: 5px; width: 200px;" type="text" id="get" name="name" />
        </div>
        <div class="form-group">
            <label>Email</label>
            <input style="padding: 5px; width: 200px;" type="text" id="get1" name="email" />
        </div>
        <div class="form-group">
            <label>Password</label>
            <input style="padding: 5px; width: 200px;" type="password" id="get2" name="password" />
        </div>
        <input class="submit" name="submitbtn" type="submit" value="Submit" />
        <br>
        <br>
        <h4 style="text-align:center;">Already registerd ?</h4>
        <a href="login.php" style="text-decoration:none">
            <h3 style="text-align:center;">Login here</h3>
        </a>
    </form>
</div>
</div>
<script>
function validation() {
    var name = document.getElementById("get").value;
    var email = document.getElementById("get1").value;
    var password = document.getElementById("get2").value;
    if (name.length < 3) {
        alert("Plese Enter Your Name");
        return false;
    }
    if (email.value == "") {
        alert("Please enter correct email");
        return false;
    }

    if (email.indexOf("@") < 1 || email.lastIndexOf(".") - email.indexOf("@") < 2) {
        alert("Please enter correct email");
        return false;
    }
    if (isNaN(password) || password.length != 5) {
        alert("Plese Enter Valid Password");
        return false;
    }
    return true;
}
</script>

</body>

</html>